# BukuKas Harian

BukuKas Harian is a React + Vite application packaged for Android with Capacitor.

## Development

```bash
npm install
npm run dev
```

## Android APK

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is generated at:

`android/app/build/outputs/apk/debug/app-debug.apk`

This version does not use Gemini or require a Gemini API key.
