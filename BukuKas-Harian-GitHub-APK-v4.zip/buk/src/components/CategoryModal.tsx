import React, { useState } from 'react';
import { CategoryItem, ColorMode, ThemeConfig, TransactionType } from '../types';
import { AVAILABLE_COLORS, AVAILABLE_ICONS } from '../utils/constants';
import { CategoryIcon } from './CategoryIcon';
import { X, Plus, Check, Trash2 } from 'lucide-react';

interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveCategory: (cat: CategoryItem) => void;
  onDeleteCategory: (id: string) => void;
  onClearCategories?: (type: TransactionType) => void;
  onResetDefaultCategories?: () => void;
  categories: CategoryItem[];
  theme: ThemeConfig;
  colorMode: ColorMode;
}

export const CategoryModal: React.FC<CategoryModalProps> = ({
  isOpen,
  onClose,
  onSaveCategory,
  onDeleteCategory,
  onClearCategories,
  onResetDefaultCategories,
  categories,
  theme,
  colorMode,
}) => {
  const [activeTab, setActiveTab] = useState<TransactionType>('expense');
  const [name, setName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Utensils');
  const [selectedColor, setSelectedColor] = useState('#f97316');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const isDark = colorMode === 'dark';
  const filteredCategories = categories.filter(c => c.type === activeTab);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Nama kategori tidak boleh kosong.');
      return;
    }

    const exists = categories.some(
      c => c.type === activeTab && c.name.toLowerCase() === name.trim().toLowerCase()
    );

    if (exists) {
      setError('Kategori dengan nama ini sudah ada.');
      return;
    }

    const newCategory: CategoryItem = {
      id: `cat-${Date.now()}`,
      name: name.trim(),
      icon: selectedIcon,
      color: selectedColor,
      type: activeTab,
      isDefault: false,
    };

    onSaveCategory(newCategory);
    setName('');
    setError('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
      <div
        id="category-modal-card"
        className={`rounded-3xl shadow-2xl border w-full max-w-lg overflow-hidden relative ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className={`p-5 text-white bg-gradient-to-r ${theme.gradient} relative`}>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X size={18} />
          </button>
          <h2 className="text-base font-bold">Kelola Kategori Transaksi</h2>
          <p className="text-xs text-white/80 mt-0.5">
            Tambah atau hapus kategori apa pun sesuai kebutuhan Anda
          </p>

          <div className="flex bg-black/20 p-1 rounded-xl mt-3 max-w-xs text-xs">
            <button
              type="button"
              id="btn-cat-expense-tab"
              onClick={() => { setActiveTab('expense'); setError(''); }}
              className={`flex-1 py-1.5 font-bold rounded-lg transition-all ${
                activeTab === 'expense' ? 'bg-white text-rose-700 shadow-xs' : 'text-white/80 hover:text-white'
              }`}
            >
              Pengeluaran
            </button>
            <button
              type="button"
              id="btn-cat-income-tab"
              onClick={() => { setActiveTab('income'); setError(''); }}
              className={`flex-1 py-1.5 font-bold rounded-lg transition-all ${
                activeTab === 'income' ? 'bg-white text-emerald-700 shadow-xs' : 'text-white/80 hover:text-white'
              }`}
            >
              Pemasukan
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Form Add New */}
          <form onSubmit={handleCreate} className="space-y-3">
            <p className="text-xs font-bold opacity-80">
              Buat Kategori Baru:
            </p>

            {error && (
              <div className="p-2.5 bg-rose-50 dark:bg-rose-950 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 rounded-xl">
                {error}
              </div>
            )}

            <div className="flex gap-2">
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Nama kategori (e.g. Asuransi, Sedekah)"
                className={`flex-1 px-3.5 py-2 rounded-xl border text-xs outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              />
              <button
                type="submit"
                id="btn-add-category-submit"
                className={`px-4 py-2 rounded-xl text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 ${theme.primary} ${theme.primaryHover}`}
              >
                <Plus size={14} />
                Tambah
              </button>
            </div>

            {/* Icon picker */}
            <div>
              <label className="text-[11px] font-bold block mb-1.5 opacity-70">
                Pilih Ikon:
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1">
                {AVAILABLE_ICONS.map(ic => (
                  <button
                    key={ic}
                    type="button"
                    onClick={() => setSelectedIcon(ic)}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all ${
                      selectedIcon === ic
                        ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 scale-110 shadow-2xs'
                        : isDark
                        ? 'border-slate-800 text-slate-400 hover:border-slate-700 hover:text-white'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <CategoryIcon iconName={ic} size={15} />
                  </button>
                ))}
              </div>
            </div>

            {/* Color picker */}
            <div>
              <label className="text-[11px] font-bold block mb-1.5 opacity-70">
                Pilih Warna Aksen:
              </label>
              <div className="flex flex-wrap gap-1.5 p-1">
                {AVAILABLE_COLORS.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setSelectedColor(c)}
                    className={`w-6 h-6 rounded-full flex items-center justify-center transition-transform ${
                      selectedColor === c ? 'scale-125 ring-2 ring-slate-900 dark:ring-white shadow-2xs' : 'hover:scale-110'
                    }`}
                    style={{ backgroundColor: c }}
                  >
                    {selectedColor === c && <Check size={12} className="text-white" />}
                  </button>
                ))}
              </div>
            </div>
          </form>

          {/* Existing Categories List - Now ALL categories can be deleted */}
          <div className={`pt-2 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <p className="text-xs font-bold opacity-80">
                Daftar Kategori ({filteredCategories.length}):
              </p>
              <div className="flex items-center gap-1.5">
                {filteredCategories.length > 0 && onClearCategories && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`Hapus SEMUA kategori ${activeTab === 'expense' ? 'pengeluaran' : 'pemasukan'}?`)) {
                        onClearCategories(activeTab);
                      }
                    }}
                    className={`text-[10px] hover:underline font-bold px-1.5 py-0.5 rounded ${
                      isDark ? 'text-rose-400' : 'text-rose-600'
                    }`}
                  >
                    Hapus Semua
                  </button>
                )}
                {onResetDefaultCategories && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('Pulihkan daftar kategori standar bawaan aplikasi?')) {
                        onResetDefaultCategories();
                      }
                    }}
                    className={`text-[10px] hover:underline font-medium px-1.5 py-0.5 rounded ${
                      isDark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    Pulihkan Standar
                  </button>
                )}
              </div>
            </div>

            {filteredCategories.length === 0 ? (
              <div className={`py-6 text-center text-xs opacity-50 border border-dashed rounded-xl ${
                isDark ? 'border-slate-700' : 'border-slate-300'
              }`}>
                Belum ada kategori {activeTab === 'expense' ? 'pengeluaran' : 'pemasukan'}. Tambahkan kategori baru di atas.
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {filteredCategories.map(cat => (
                  <div
                    key={cat.id}
                    className={`p-2 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                      isDark ? 'border-slate-800 bg-slate-800/40 hover:bg-slate-800/70' : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div
                        className="w-6 h-6 rounded-md flex items-center justify-center text-white shrink-0"
                        style={{ backgroundColor: cat.color }}
                      >
                        <CategoryIcon iconName={cat.icon} size={13} />
                      </div>
                      <span className="font-semibold truncate max-w-[105px]">{cat.name}</span>
                    </div>

                    <button
                      type="button"
                      id={`btn-del-cat-${cat.id}`}
                      onClick={() => onDeleteCategory(cat.id)}
                      className={`p-1 rounded-md transition-colors shrink-0 ${
                        isDark ? 'text-slate-400 hover:text-rose-400' : 'text-slate-400 hover:text-rose-600'
                      }`}
                      title={`Hapus kategori ${cat.name}`}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
