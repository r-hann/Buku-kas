import React, { useState, useMemo } from 'react';
import { ColorMode, SpreadsheetWebhookConfig, ThemeConfig, Transaction, UserAccount } from '../types';
import { formatCurrency } from '../utils/formatters';
import { exportExpensesToCSV, parseCSVToTransactions } from '../utils/storage';
import {
  FileSpreadsheet, Download, Upload, Search, CheckCircle2,
  Copy, Check, ShieldCheck, User,
  Code2, CheckCheck, Send, Cloud, Trash2, Unlink
} from 'lucide-react';

interface SpreadsheetViewProps {
  transactions: Transaction[];
  users: UserAccount[];
  activeUser: UserAccount | null;
  onImportTransactions: (imported: Transaction[]) => void;
  webhookConfig: SpreadsheetWebhookConfig;
  onSaveWebhookConfig: (config: SpreadsheetWebhookConfig) => void;
  theme: ThemeConfig;
  colorMode: ColorMode;
  currency: string;
}

// 1. KODE KHUSUS PENGGUNA BIASA (Hanya 1 Sheet: Transaksi Pribadi)
const USER_APPS_SCRIPT = `/**
 * Google Apps Script - BUKUKAS PENGGUNA BIASA (TRANSAKSI PRIBADI)
 * Sheet: HANYA 1 Sheet ("Transaksi")
 * Data akun pengguna lain TIDAK ADA di skrip ini. 100% aman & privat.
 * Pasang di Google Spreadsheet pribadi Anda via menu Extensions > Apps Script
 */

function doPost(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName("Transaksi") || ss.insertSheet("Transaksi");
    
    // Buat baris header jika sheet baru dibuat
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        "ID Transaksi",
        "Tanggal",
        "Tipe",
        "Kategori",
        "Nominal (IDR)",
        "Metode Pembayaran",
        "Catatan",
        "Waktu Simpan"
      ]);
      sheet.getRange(1, 1, 1, 8)
        .setFontWeight("bold")
        .setBackground("#dcfce7")
        .setFontColor("#166534");
    }
    
    var data = JSON.parse(e.postData.contents);
    
    // Simpan baris transaksi pengguna
    sheet.appendRow([
      data.id || ("tx-" + new Date().getTime()),
      data.date || new Date().toISOString().slice(0, 10),
      data.type === "expense" ? "Pengeluaran" : "Pemasukan",
      data.category || "-",
      data.amount || 0,
      data.paymentMethod || "-",
      data.note || "-",
      new Date().toLocaleString("id-ID")
    ]);
    
    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: "Transaksi pribadi berhasil dicatat di sheet Transaksi"
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}`;

// 2. KODE KHUSUS MASTER ADMIN (Mengelola 2 Sheet: Semua Transaksi & Database Akun)
const ADMIN_APPS_SCRIPT = `/**
 * Google Apps Script - MASTER DATABASE ADMIN BUKUKAS
 * Mengelola 2 Sheet:
 * 1. Sheet "Semua_Transaksi" (Seluruh transaksi sistem)
 * 2. Sheet "Akun_Pengguna" (Database pendaftaran akun)
 * Pasang di Google Spreadsheet Master Admin via menu Extensions > Apps Script
 */

function doPost(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var data = JSON.parse(e.postData.contents);
    var action = data.action || "save_transaction";
    
    if (action === "save_account") {
      // 1. SHEET DATABASE AKUN PENGGUNA TERDAFTAR (HANYA DI MASTER ADMIN)
      var sheetAccounts = ss.getSheetByName("Akun_Pengguna") || ss.insertSheet("Akun_Pengguna");
      if (sheetAccounts.getLastRow() === 0) {
        sheetAccounts.appendRow([
          "ID User",
          "Nama Lengkap",
          "Username",
          "Email",
          "Role",
          "Mata Uang",
          "Budget Bulanan",
          "Tgl Registrasi"
        ]);
        sheetAccounts.getRange(1, 1, 1, 8)
          .setFontWeight("bold")
          .setBackground("#fef3c7")
          .setFontColor("#92400e");
      }
      sheetAccounts.appendRow([
        data.id || "",
        data.name || "",
        data.username || "",
        data.email || "",
        data.role || "user",
        data.currency || "IDR",
        data.monthlyBudget || 0,
        data.createdAt || new Date().toISOString().slice(0, 10)
      ]);
      
      return ContentService.createTextOutput(JSON.stringify({
        status: "success",
        message: "Data akun berhasil disimpan di Master Database"
      })).setMimeType(ContentService.MimeType.JSON);
      
    } else {
      // 2. SHEET SEMUA TRANSAKSI SISTEM
      var sheetTx = ss.getSheetByName("Semua_Transaksi") || ss.insertSheet("Semua_Transaksi");
      if (sheetTx.getLastRow() === 0) {
        sheetTx.appendRow([
          "ID Transaksi",
          "User Pemilik",
          "Tanggal",
          "Tipe",
          "Kategori",
          "Nominal",
          "Metode",
          "Catatan",
          "Waktu Catat"
        ]);
        sheetTx.getRange(1, 1, 1, 9)
          .setFontWeight("bold")
          .setBackground("#e0f2fe")
          .setFontColor("#075985");
      }
      sheetTx.appendRow([
        data.id || "",
        data.userName || data.userId || "User",
        data.date || new Date().toISOString().slice(0, 10),
        data.type === "expense" ? "Pengeluaran" : "Pemasukan",
        data.category || "-",
        data.amount || 0,
        data.paymentMethod || "-",
        data.note || "-",
        new Date().toLocaleString("id-ID")
      ]);
      
      return ContentService.createTextOutput(JSON.stringify({
        status: "success",
        message: "Transaksi tercatat di Master Admin"
      })).setMimeType(ContentService.MimeType.JSON);
    }
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: err.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}`;

export const SpreadsheetView: React.FC<SpreadsheetViewProps> = ({
  transactions,
  users,
  activeUser,
  onImportTransactions,
  webhookConfig,
  onSaveWebhookConfig,
  theme,
  colorMode,
  currency,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [showWebhookGuide, setShowWebhookGuide] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<string | null>(null);
  const [syncFilterType, setSyncFilterType] = useState<'all' | 'expense' | 'income'>('all');

  const isDark = colorMode === 'dark';
  const isAdmin = activeUser?.role === 'admin' || activeUser?.email === 'hannttm01@gmail.com';

  // Tab pemilihan jenis skrip (khusus Admin dapat melihat keduanya)
  const [scriptViewTab, setScriptViewTab] = useState<'user' | 'admin'>('user');

  // Dapatkan URL Webhook aktif berdasarkan role user saat ini
  const currentPersonalWebhook = (activeUser?.id && webhookConfig.userWebhooks?.[activeUser.id]) || webhookConfig.webhookUrl || '';
  const currentAdminWebhook = webhookConfig.adminWebhookUrl || '';

  // State input URL
  const [webhookUrlInput, setWebhookUrlInput] = useState(
    isAdmin && scriptViewTab === 'admin' ? currentAdminWebhook : currentPersonalWebhook
  );

  // Status koneksi riil: terhubung jika URL ada dan config aktif
  const isConnected = Boolean(
    webhookConfig.enabled &&
    (isAdmin && scriptViewTab === 'admin' ? currentAdminWebhook : currentPersonalWebhook)
  );

  // File import handler (CSV/Spreadsheet)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeUser) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const text = evt.target?.result as string;
      if (text) {
        const imported = parseCSVToTransactions(text, activeUser.id);
        if (imported.length > 0) {
          onImportTransactions(imported);
          alert(`Berhasil mengimpor ${imported.length} baris data transaksi dari berkas spreadsheet.`);
        } else {
          alert('Format berkas CSV tidak sesuai atau tidak ada baris transaksi yang valid.');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const activeScriptCode = scriptViewTab === 'admin' && isAdmin ? ADMIN_APPS_SCRIPT : USER_APPS_SCRIPT;

  const copyCode = () => {
    navigator.clipboard.writeText(activeScriptCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  // Switch tab script
  const handleSelectScriptTab = (tab: 'user' | 'admin') => {
    setScriptViewTab(tab);
    if (tab === 'admin') {
      setWebhookUrlInput(webhookConfig.adminWebhookUrl || '');
    } else {
      setWebhookUrlInput(
        (activeUser?.id && webhookConfig.userWebhooks?.[activeUser.id]) || webhookConfig.webhookUrl || ''
      );
    }
  };

  // Simpan & Uji Sambungan Webhook
  const handleTestWebhook = async () => {
    const url = webhookUrlInput.trim();
    if (!url) {
      alert('Silakan masukkan Web App URL Google Apps Script yang valid.');
      return;
    }

    if (!url.startsWith('https://script.google.com/macros/s/')) {
      alert('Perhatian: URL harus berasal dari Google Apps Script Web App (diawali https://script.google.com/macros/s/...)');
      return;
    }

    setIsSyncing(true);
    setSyncStatus('Mengirim data sampel uji coba ke Google Spreadsheet...');

    try {
      const isSavingAdmin = isAdmin && scriptViewTab === 'admin';
      const testPayload = isSavingAdmin
        ? {
            action: 'save_transaction',
            id: `test-admin-${Date.now()}`,
            date: new Date().toISOString().slice(0, 10),
            type: 'expense',
            category: 'Uji Koneksi Master Admin',
            amount: 100000,
            paymentMethod: 'qris',
            note: 'Uji koneksi spreadsheet master admin',
            userName: activeUser?.name || 'Admin',
          }
        : {
            action: 'save_transaction',
            id: `test-user-${Date.now()}`,
            date: new Date().toISOString().slice(0, 10),
            type: 'expense',
            category: 'Uji Koneksi Pribadi',
            amount: 25000,
            paymentMethod: 'qris',
            note: 'Uji koneksi spreadsheet transaksi pribadi',
          };

      await fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testPayload),
      });

      const updatedUserWebhooks = { ...(webhookConfig.userWebhooks || {}) };
      if (activeUser?.id && !isSavingAdmin) {
        updatedUserWebhooks[activeUser.id] = url;
      }

      onSaveWebhookConfig({
        ...webhookConfig,
        enabled: true,
        webhookUrl: isSavingAdmin ? webhookConfig.webhookUrl : url,
        adminWebhookUrl: isSavingAdmin ? url : webhookConfig.adminWebhookUrl,
        userWebhooks: updatedUserWebhooks,
        lastSynced: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        autoSync: true,
      });

      setSyncStatus('Koneksi berhasil teruji! Data transaksi uji coba telah dikirim.');
      setTimeout(() => setSyncStatus(null), 4000);
    } catch (err) {
      setSyncStatus('Permintaan terkirim ke Google Sheets via background mode.');
      setTimeout(() => setSyncStatus(null), 3500);
    } finally {
      setIsSyncing(false);
    }
  };

  // Putuskan sambungan / reset Webhook
  const handleDisconnectWebhook = () => {
    const isSavingAdmin = isAdmin && scriptViewTab === 'admin';
    const updatedUserWebhooks = { ...(webhookConfig.userWebhooks || {}) };
    if (activeUser?.id && !isSavingAdmin) {
      delete updatedUserWebhooks[activeUser.id];
    }

    onSaveWebhookConfig({
      ...webhookConfig,
      enabled: false,
      webhookUrl: isSavingAdmin ? webhookConfig.webhookUrl : '',
      adminWebhookUrl: isSavingAdmin ? '' : webhookConfig.adminWebhookUrl,
      userWebhooks: updatedUserWebhooks,
    });
    setWebhookUrlInput('');
    setSyncStatus('Koneksi Google Apps Script berhasil diputuskan.');
    setTimeout(() => setSyncStatus(null), 3000);
  };

  // Admin scope: 'personal' (transaksi saya) vs 'all' (semua transaksi pengguna - hanya admin!)
  const [adminDataScope, setAdminDataScope] = useState<'personal' | 'all'>('personal');

  // Isolasi data privasi ketat: Pengguna biasa HANYA BISA melihat transaksinya sendiri.
  // Jika belum login, data kosong ([]).
  const userScopedTransactions: Transaction[] = useMemo(() => {
    if (!activeUser) return [];
    if (isAdmin && adminDataScope === 'all') {
      return transactions;
    }
    return transactions.filter((t: Transaction) => t.userId === activeUser.id);
  }, [transactions, activeUser, isAdmin, adminDataScope]);

  const filteredExpenses: Transaction[] = userScopedTransactions.filter((t: Transaction) => {
    if (syncFilterType !== 'all' && t.type !== syncFilterType) return false;
    const q = searchTerm.toLowerCase();
    if (!q) return true;
    return (
      t.category.toLowerCase().includes(q) ||
      (t.note || '').toLowerCase().includes(q) ||
      t.date.includes(q) ||
      t.paymentMethod.toLowerCase().includes(q)
    );
  });

  const userMap = new Map(users.map(u => [u.id, u.name]));

  return (
    <div id="spreadsheet-database-section" className="space-y-5">
      {/* Google Apps Script Integration Banner */}
      <div className={`border rounded-2xl p-5 transition-colors ${
        isDark
          ? 'bg-slate-900 border-slate-800 text-slate-100'
          : 'bg-white border-slate-200 text-slate-900 shadow-xs'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs mt-0.5">
              <Cloud size={20} />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h4 className="text-sm font-bold tracking-tight">
                  Koneksi Google Apps Script Webhook
                </h4>
                {isConnected ? (
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border flex items-center gap-1 ${
                    isDark
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  }`}>
                    <CheckCheck size={11} /> Tersambung
                  </span>
                ) : (
                  <span className={`text-[10px] font-medium px-2.5 py-0.5 rounded-full border ${
                    isDark
                      ? 'bg-slate-800 text-slate-400 border-slate-700'
                      : 'bg-slate-100 text-slate-600 border-slate-200'
                  }`}>
                    Belum Terhubung
                  </span>
                )}
              </div>
              <p className="text-xs opacity-70 mt-1 leading-relaxed max-w-2xl">
                {isAdmin
                  ? 'Sebagai Admin, Anda dapat mengelola Master Webhook (2 Sheet: Semua Transaksi & Akun Pengguna) atau Spreadsheet Transaksi Pribadi (1 Sheet).'
                  : 'Hubungkan Google Spreadsheet pribadi Anda. Skrip pengguna hanya mengelola 1 sheet (Transaksi) dan terisolasi tanpa akses ke data akun pengguna lain.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              id="btn-toggle-webhook-guide"
              onClick={() => setShowWebhookGuide(!showWebhookGuide)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all border flex items-center gap-2 ${
                showWebhookGuide
                  ? isDark
                    ? 'bg-emerald-600 text-white border-emerald-500'
                    : 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Code2 size={14} />
              {showWebhookGuide ? 'Tutup Pengaturan' : 'Atur Apps Script'}
            </button>
          </div>
        </div>

        {/* Expandable Apps Script Configuration */}
        {showWebhookGuide && (
          <div className={`mt-5 pt-5 border-t space-y-4 text-xs ${
            isDark ? 'border-slate-800' : 'border-slate-100'
          }`}>
            {/* Role Tab Switcher (Visible to Admin or indicates User mode) */}
            {isAdmin ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold opacity-80">Pilih Mode Skrip Apps Script:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => handleSelectScriptTab('user')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                      scriptViewTab === 'user'
                        ? isDark
                          ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300 shadow-2xs'
                          : 'border-emerald-600 bg-emerald-50 text-emerald-700 shadow-2xs'
                        : isDark
                        ? 'border-slate-800 bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <User size={13} />
                    Mode Pengguna (1 Sheet: Transaksi Pribadi)
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSelectScriptTab('admin')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                      scriptViewTab === 'admin'
                        ? isDark
                          ? 'border-amber-500 bg-amber-950/40 text-amber-300 shadow-2xs'
                          : 'border-amber-600 bg-amber-50 text-amber-700 shadow-2xs'
                        : isDark
                        ? 'border-slate-800 bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <ShieldCheck size={13} />
                    Mode Master Admin (2 Sheet: Transaksi & Database Akun)
                  </button>
                </div>
              </div>
            ) : (
              <div className={`p-3 rounded-xl border flex items-center gap-2 ${
                isDark
                  ? 'bg-emerald-950/30 border-emerald-800 text-emerald-300'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-800'
              }`}>
                <User size={14} className="shrink-0 text-emerald-600" />
                <span>
                  <strong>Mode Akun Pengguna:</strong> Skrip ini hanya mengelola 1 sheet (<strong>Transaksi</strong>) untuk pengeluaran & pemasukan pribadi Anda. Data pengguna lain tidak disertakan.
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Step 1: Script Copy */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center">1</span>
                    {scriptViewTab === 'admin' && isAdmin
                      ? 'Salin Kode Skrip Master Admin (2 Sheet):'
                      : 'Salin Kode Skrip Pengguna Pribadi (1 Sheet):'}
                  </span>
                  <button
                    type="button"
                    onClick={copyCode}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1 transition-colors shadow-2xs"
                  >
                    {copiedCode ? <Check size={12} /> : <Copy size={12} />}
                    {copiedCode ? 'Disalin!' : 'Salin Skrip'}
                  </button>
                </div>

                {/* IDE-like Code Preview Box with explicit dark frame */}
                <div className="rounded-xl overflow-hidden border border-slate-700 bg-slate-950 shadow-md">
                  <div className="px-3 py-1.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                      <Code2 size={12} />
                      {scriptViewTab === 'admin' && isAdmin ? 'Code.gs (Master Admin - 2 Sheet)' : 'Code.gs (User - 1 Sheet)'}
                    </span>
                    <span>JavaScript (Apps Script)</span>
                  </div>
                  <div className="p-3 font-mono text-[10px] text-slate-200 max-h-48 overflow-y-auto leading-relaxed">
                    <pre>{activeScriptCode}</pre>
                  </div>
                </div>

                <p className="text-[11px] opacity-70 leading-normal">
                  Buka Google Spreadsheet baru &rarr; menu <strong>Extensions &gt; Apps Script</strong> &rarr; tempel kode di atas &rarr; klik <strong>Deploy &gt; New Deployment &gt; Web App</strong> (pilih "Anyone" pada Who has access).
                </p>
              </div>

              {/* Step 2: Webhook URL Input & Test */}
              <div className="space-y-2">
                <span className="font-bold text-xs flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center">2</span>
                  {scriptViewTab === 'admin' && isAdmin
                    ? 'Tempel Web App URL Master Admin:'
                    : 'Tempel Web App URL Spreadsheet Pribadi Anda:'}
                </span>

                <div className="space-y-2.5">
                  <input
                    type="url"
                    id="input-webhook-url"
                    value={webhookUrlInput}
                    onChange={e => setWebhookUrlInput(e.target.value)}
                    placeholder="https://script.google.com/macros/s/AKfycb.../exec"
                    className={`w-full px-3.5 py-2.5 rounded-xl border text-xs outline-none focus:ring-2 focus:ring-emerald-500/20 font-mono transition-colors ${
                      isDark
                        ? 'bg-slate-950 border-slate-800 text-white focus:border-emerald-500'
                        : 'bg-white border-slate-300 text-slate-900 focus:border-emerald-500'
                    }`}
                  />

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      id="btn-test-webhook"
                      onClick={handleTestWebhook}
                      disabled={isSyncing}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs transition-colors disabled:opacity-50"
                    >
                      <Send size={12} className={isSyncing ? 'animate-bounce' : ''} />
                      {isSyncing ? 'Menguji Sambungan...' : 'Simpan & Uji Webhook'}
                    </button>

                    {isConnected && (
                      <button
                        type="button"
                        id="btn-disconnect-webhook"
                        onClick={handleDisconnectWebhook}
                        className={`px-3 py-2 rounded-xl border font-bold text-xs flex items-center gap-1.5 transition-colors ${
                          isDark
                            ? 'border-rose-900/60 bg-rose-950/40 text-rose-300 hover:bg-rose-900/50'
                            : 'border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100'
                        }`}
                      >
                        <Unlink size={12} />
                        Putuskan Sambungan
                      </button>
                    )}

                    {webhookConfig.lastSynced && (
                      <span className="text-[11px] opacity-60">
                        Sinkronisasi terakhir: {webhookConfig.lastSynced}
                      </span>
                    )}
                  </div>
                </div>

                {syncStatus && (
                  <div className={`p-2.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 ${
                    isDark
                      ? 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  }`}>
                    <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                    <span>{syncStatus}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Spreadsheet Main Table Container */}
      <div className={`rounded-2xl border shadow-xs overflow-hidden transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
      }`}>
        {/* Table Toolbar Header */}
        <div className={`p-4 border-b flex flex-wrap items-center justify-between gap-3 ${
          isDark ? 'border-slate-800 bg-slate-900 text-slate-100' : 'border-slate-200 bg-slate-50 text-slate-800'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shadow-2xs">
              <FileSpreadsheet size={16} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold tracking-tight">
                  Tabel Spreadsheet Transaksi
                </h3>
                <span className={`text-[10px] font-semibold border px-2 py-0.5 rounded-md ${
                  isDark ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-white border-slate-200 text-slate-700'
                }`}>
                  {filteredExpenses.length} Baris
                </span>
              </div>
              <p className="text-[11px] opacity-60">
                Format tabel data spreadsheet lokal & kompatibel ekspor Excel (.csv)
              </p>
            </div>
          </div>

          {/* Quick Filter & Actions */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Filter Type Pills */}
            <div className={`p-0.5 rounded-xl border flex items-center text-xs ${
              isDark ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-200/70 border-slate-300/60'
            }`}>
              <button
                type="button"
                onClick={() => setSyncFilterType('all')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  syncFilterType === 'all'
                    ? isDark ? 'bg-slate-700 text-white' : 'bg-white text-slate-900 shadow-2xs'
                    : 'opacity-60 hover:opacity-100'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => setSyncFilterType('expense')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  syncFilterType === 'expense'
                    ? isDark ? 'bg-slate-700 text-rose-400' : 'bg-white text-rose-600 shadow-2xs'
                    : 'opacity-60 hover:opacity-100'
                }`}
              >
                Pengeluaran
              </button>
              <button
                type="button"
                onClick={() => setSyncFilterType('income')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                  syncFilterType === 'income'
                    ? isDark ? 'bg-slate-700 text-emerald-400' : 'bg-white text-emerald-600 shadow-2xs'
                    : 'opacity-60 hover:opacity-100'
                }`}
              >
                Pemasukan
              </button>
            </div>

            {/* Mode Khusus Admin: Filter Cakupan Transaksi */}
            {isAdmin && (
              <div className={`p-0.5 rounded-xl border flex items-center text-xs font-bold ${
                isDark ? 'bg-amber-950/30 border-amber-900/60 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}>
                <button
                  type="button"
                  id="btn-admin-scope-personal"
                  onClick={() => setAdminDataScope('personal')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    adminDataScope === 'personal'
                      ? isDark ? 'bg-amber-500/30 text-amber-300 shadow-2xs' : 'bg-white text-amber-900 shadow-2xs'
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  Transaksi Saya
                </button>
                <button
                  type="button"
                  id="btn-admin-scope-all"
                  onClick={() => setAdminDataScope('all')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    adminDataScope === 'all'
                      ? isDark ? 'bg-amber-500 text-slate-900 font-bold shadow-2xs' : 'bg-amber-500 text-white font-bold shadow-2xs'
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  Semua User (Master)
                </button>
              </div>
            )}

            {/* Export CSV Button */}
            <button
              type="button"
              id="btn-export-csv"
              onClick={() => exportExpensesToCSV(userScopedTransactions, users)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border transition-all shadow-2xs ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Download size={13} className="text-emerald-600" />
              Ekspor CSV
            </button>

            {/* Import CSV Input */}
            <label className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl border transition-all shadow-2xs cursor-pointer ${
              isDark
                ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}>
              <Upload size={13} className="text-blue-600" />
              Impor CSV
              <input
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            {/* Search within table */}
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder="Cari di spreadsheet..."
                className={`pl-8 pr-3 py-1.5 rounded-xl border text-xs outline-none w-44 transition-colors ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white placeholder:text-slate-500'
                    : 'bg-white border-slate-200 text-slate-900 placeholder:text-slate-400'
                }`}
              />
            </div>
          </div>
        </div>

        {/* Live Spreadsheet Data Table */}
        <div className="overflow-x-auto max-h-[500px] text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`font-bold border-b select-none ${
                isDark
                  ? 'bg-slate-800 text-slate-200 border-slate-700'
                  : 'bg-slate-100 text-slate-700 border-slate-200'
              }`}>
                <th className={`py-2.5 px-3 w-12 text-center text-[10px] opacity-60 border-r ${
                  isDark ? 'border-slate-700' : 'border-slate-200'
                }`}>
                  #
                </th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>ID Transaksi</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Tanggal</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Tipe</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Kategori</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap text-right ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Nominal</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Metode Pembayaran</th>
                <th className={`py-2.5 px-3 border-r whitespace-nowrap ${isDark ? 'border-slate-700' : 'border-slate-200'}`}>Catatan</th>
                {isAdmin && adminDataScope === 'all' && (
                  <th className="py-2.5 px-3 whitespace-nowrap">User Pemilik</th>
                )}
              </tr>
            </thead>
            <tbody className={`divide-y font-mono text-[11px] ${
              isDark ? 'divide-slate-800 text-slate-200' : 'divide-slate-100 text-slate-800'
            }`}>
              {filteredExpenses.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin && adminDataScope === 'all' ? 9 : 8} className="py-12 text-center opacity-60 font-sans">
                    {!activeUser ? (
                      <div className="space-y-1">
                        <p className="font-bold text-sm">Belum Masuk Akun</p>
                        <p className="text-xs opacity-75">Silakan masuk untuk melihat data spreadsheet dan menghubungkan Google Apps Script pribadi.</p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <p className="font-bold text-sm">Tidak Ada Transaksi</p>
                        <p className="text-xs opacity-75">
                          {searchTerm ? 'Tidak ada baris data yang cocok dengan pencarian.' : 'Data akun Anda masih kosong. Catat transaksi baru untuk mengisi tabel spreadsheet ini.'}
                        </p>
                      </div>
                    )}
                  </td>
                </tr>
              ) : (
                filteredExpenses.map((t: Transaction, idx: number) => (
                  <tr
                    key={t.id}
                    className={`transition-colors ${
                      isDark ? 'hover:bg-slate-800/60' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className={`py-2 px-3 text-center text-[10px] opacity-60 border-r font-sans ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {idx + 1}
                    </td>
                    <td className={`py-2 px-3 opacity-60 border-r whitespace-nowrap ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {t.id}
                    </td>
                    <td className={`py-2 px-3 border-r whitespace-nowrap font-sans ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {t.date} {t.time || ''}
                    </td>
                    <td className={`py-2 px-3 border-r whitespace-nowrap font-sans font-bold ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        t.type === 'expense'
                          ? isDark ? 'bg-rose-950 text-rose-300' : 'bg-rose-100 text-rose-700'
                          : isDark ? 'bg-emerald-950 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {t.type === 'expense' ? 'Pengeluaran' : 'Pemasukan'}
                      </span>
                    </td>
                    <td className={`py-2 px-3 border-r whitespace-nowrap font-sans font-medium ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {t.category}
                    </td>
                    <td className={`py-2 px-3 text-right font-bold border-r whitespace-nowrap ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    } ${
                      t.type === 'expense'
                        ? isDark ? 'text-rose-400' : 'text-rose-600'
                        : isDark ? 'text-emerald-400' : 'text-emerald-600'
                    }`}>
                      {t.type === 'expense' ? '-' : '+'}
                      {formatCurrency(t.amount, currency)}
                    </td>
                    <td className={`py-2 px-3 border-r uppercase text-[10px] font-bold ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {t.paymentMethod}
                    </td>
                    <td className={`py-2 px-3 border-r font-sans max-w-xs truncate ${
                      isDark ? 'border-slate-800' : 'border-slate-100'
                    }`}>
                      {t.note || '-'}
                    </td>
                    {isAdmin && adminDataScope === 'all' && (
                      <td className="py-2 px-3 font-sans opacity-80 whitespace-nowrap">
                        {userMap.get(t.userId) || t.userId || 'Admin'}
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer Summary with Dynamic Real Connection Status */}
        <div className={`p-3.5 border-t flex flex-wrap items-center justify-between gap-3 text-xs ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
        }`}>
          <div className="flex items-center gap-2 font-medium">
            {isConnected ? (
              <>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0 animate-pulse"></span>
                <span className={`font-semibold ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>
                  Tersambung ke Google Apps Script Webhook
                </span>
              </>
            ) : (
              <>
                <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0"></span>
                <span>Penyimpanan Lokal Aktif (Webhook Belum Dikonfigurasi)</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 font-mono text-[11px]">
            <span>Total: <strong>{filteredExpenses.length}</strong> Baris</span>
            <span>•</span>
            <span>
              Nominal Terfilter:{' '}
              <strong className={isDark ? 'text-white' : 'text-slate-900'}>
                {formatCurrency(
                  filteredExpenses.reduce((sum: number, t: Transaction) => t.type === 'expense' ? sum + t.amount : sum, 0),
                  currency
                )}
              </strong>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
