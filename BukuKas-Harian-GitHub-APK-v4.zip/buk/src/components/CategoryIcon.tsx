import React from 'react';
import {
  Utensils, Coffee, Car, Bus, ShoppingBag, ShoppingCart,
  Zap, Wifi, Smartphone, Film, Music, Gamepad2,
  HeartPulse, Dumbbell, GraduationCap, Book, Home, PiggyBank,
  Briefcase, Store, Sparkles, TrendingUp, Gift, Wallet,
  Coins, CreditCard, MoreHorizontal, CircleDollarSign, LucideProps
} from 'lucide-react';

interface CategoryIconProps extends LucideProps {
  name?: string;
  iconName?: string;
  className?: string;
  size?: number;
}

const ICON_MAP: Record<string, React.FC<LucideProps>> = {
  Utensils,
  Coffee,
  Car,
  Bus,
  ShoppingBag,
  ShoppingCart,
  Zap,
  Wifi,
  Smartphone,
  Film,
  Music,
  Gamepad2,
  HeartPulse,
  Dumbbell,
  GraduationCap,
  Book,
  Home,
  PiggyBank,
  Briefcase,
  Store,
  Sparkles,
  TrendingUp,
  Gift,
  Wallet,
  Coins,
  CreditCard,
  MoreHorizontal,
  CircleDollarSign,
};

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, iconName, className = '', size = 18, ...props }) => {
  const finalName = name || iconName || 'CircleDollarSign';
  const Component = ICON_MAP[finalName] || CircleDollarSign;
  return <Component size={size} className={className} {...props} />;
};
