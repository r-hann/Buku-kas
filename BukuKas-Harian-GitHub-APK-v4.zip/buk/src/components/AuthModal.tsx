import React, { useState, useRef } from 'react';
import { ColorMode, ThemeConfig, UserAccount } from '../types';
import {
  User, Lock, Mail, Check, LogIn, UserPlus, X, Wallet,
  KeyRound, ShieldCheck, Upload, AlertCircle, Camera, CheckCircle2, LogOut
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserAccount[];
  activeUser: UserAccount | null;
  onSelectUser: (user: UserAccount | null) => void;
  onRegisterUser: (newUser: UserAccount) => void;
  onResetPassword: (userId: string, newPassword: string) => void;
  theme: ThemeConfig;
  colorMode: ColorMode;
}

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  users,
  activeUser,
  onSelectUser,
  onRegisterUser,
  onResetPassword,
  theme,
  colorMode,
}) => {
  const [tab, setTab] = useState<'login' | 'signup' | 'reset'>('login');
  
  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPin, setLoginPin] = useState('');
  const [loginError, setLoginError] = useState('');

  // Signup form state
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [pin, setPin] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0]);
  const [customAvatarPreview, setCustomAvatarPreview] = useState<string | null>(null);
  const [monthlyBudget, setMonthlyBudget] = useState('4000000');
  const [currency, setCurrency] = useState<'IDR' | 'USD' | 'MYR' | 'SGD' | 'EUR'>('IDR');
  const [signupError, setSignupError] = useState('');

  // Reset password state
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [resetMessage, setResetMessage] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const isDark = colorMode === 'dark';

  // Handle image upload from user's gallery / local files
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate size (max 3MB for base64 local storage)
    if (file.size > 3 * 1024 * 1024) {
      setSignupError('Ukuran gambar terlalu besar. Maksimal 3 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      const result = evt.target?.result as string;
      if (result) {
        setCustomAvatarPreview(result);
        setSelectedAvatar(result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const cleanId = loginIdentifier.trim().toLowerCase();
    const cleanPw = loginPin.trim();

    if (!cleanId) {
      setLoginError('Silakan masukkan username atau email.');
      return;
    }

    if (!cleanPw) {
      setLoginError('Silakan masukkan kata sandi.');
      return;
    }

    // Dukungan akun admin yang diminta pengguna: username Hann, pw abogoboga
    if (cleanId === 'hann' && cleanPw === 'abogoboga') {
      const adminTarget = users.find(
        u => u.username.toLowerCase() === 'hann' || u.role === 'admin'
      );
      if (adminTarget) {
        onSelectUser({
          ...adminTarget,
          name: adminTarget.name || 'Hann',
          username: 'Hann',
          password: 'abogoboga',
          role: 'admin',
        });
        onClose();
        return;
      }
    }

    const target = users.find(
      u => u.username.toLowerCase() === cleanId ||
           u.email.toLowerCase() === cleanId
    );

    if (!target) {
      setLoginError('Akun tidak ditemukan. Periksa username atau buat akun baru di tab Daftar.');
      return;
    }

    if (target.password && target.password !== cleanPw) {
      setLoginError('Kata sandi salah. Silakan coba lagi atau gunakan menu Ganti Sandi.');
      return;
    }

    onSelectUser(target);
    onClose();
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError('');

    const trimmedName = name.trim();
    const rawUsername = username.trim().toLowerCase().replace(/\s+/g, '_');
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedName) {
      setSignupError('Nama lengkap wajib diisi.');
      return;
    }

    if (!rawUsername) {
      setSignupError('Username wajib diisi.');
      return;
    }

    // Validation: Username must not contain special chars other than underscore and letters/digits
    if (!/^[a-z0-9_]{3,20}$/.test(rawUsername)) {
      setSignupError('Username harus 3-20 karakter, hanya huruf, angka, atau garis bawah (_).');
      return;
    }

    // Validation: Username MUST BE UNIQUE
    const isUsernameTaken = users.some(u => u.username.toLowerCase() === rawUsername);
    if (isUsernameTaken) {
      setSignupError(`Username @${rawUsername} sudah dipakai pengguna lain. Silakan pilih username unik.`);
      return;
    }

    // Validation: Email uniqueness (if provided)
    if (trimmedEmail) {
      const isEmailTaken = users.some(u => u.email.toLowerCase() === trimmedEmail);
      if (isEmailTaken) {
        setSignupError('Email ini sudah terdaftar pada akun lain. Gunakan email berbeda.');
        return;
      }
    }

    const isFirstUser = users.length === 0;
    const isOwnerEmail = trimmedEmail === 'hannttm01@gmail.com';

    const newUser: UserAccount = {
      id: `usr-${Date.now()}`,
      name: trimmedName,
      username: rawUsername,
      email: trimmedEmail || `${rawUsername}@bukukas.local`,
      password: pin.trim() || '1234',
      role: isFirstUser || isOwnerEmail ? 'admin' : 'user',
      avatar: selectedAvatar,
      createdAt: new Date().toISOString().slice(0, 10),
      monthlyBudget: parseFloat(monthlyBudget) || 4000000,
      currency,
    };

    onRegisterUser(newUser);
    onClose();
  };

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setResetMessage(null);

    const target = users.find(
      u => u.username.toLowerCase() === resetIdentifier.trim().toLowerCase() ||
           u.email.toLowerCase() === resetIdentifier.trim().toLowerCase()
    );

    if (!target) {
      setResetMessage({ type: 'error', text: 'Akun dengan username atau email tersebut tidak ditemukan!' });
      return;
    }

    if (!newPassword.trim() || newPassword.length < 4) {
      setResetMessage({ type: 'error', text: 'Sandi / PIN baru minimal 4 karakter atau angka.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      setResetMessage({ type: 'error', text: 'Konfirmasi sandi tidak sesuai. Pastikan keduanya sama persis.' });
      return;
    }

    onResetPassword(target.id, newPassword.trim());
    setResetMessage({
      type: 'success',
      text: `Sandi untuk akun @${target.username} berhasil diubah.`
    });

    setTimeout(() => {
      onSelectUser({ ...target, password: newPassword.trim() });
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fadeIn">
      <div
        id="auth-modal-card"
        className={`rounded-2xl shadow-xl border w-full max-w-md overflow-hidden relative ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
        }`}
      >
        {/* Modal Top Header */}
        <div className={`p-5 text-white ${theme.primary} relative flex items-center justify-between`}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
              <User size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight">Akun Pengguna</h2>
              <p className="text-xs text-white/80">Kelola profil dan akses buku kas Anda</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-black/10 hover:bg-black/20 text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className={`flex border-b text-xs font-bold ${
          isDark ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-slate-50'
        }`}>
          <button
            type="button"
            id="tab-login"
            onClick={() => { setTab('login'); setLoginError(''); }}
            className={`flex-1 py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              tab === 'login'
                ? isDark
                  ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                  : 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <LogIn size={13} />
            Masuk
          </button>
          <button
            type="button"
            id="tab-signup"
            onClick={() => { setTab('signup'); setSignupError(''); }}
            className={`flex-1 py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              tab === 'signup'
                ? isDark
                  ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                  : 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <UserPlus size={13} />
            Daftar Akun Baru
          </button>
          <button
            type="button"
            id="tab-reset"
            onClick={() => { setTab('reset'); setResetMessage(null); }}
            className={`flex-1 py-3 text-center border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              tab === 'reset'
                ? isDark
                  ? 'border-emerald-500 text-emerald-400 bg-slate-900'
                  : 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <KeyRound size={13} />
            Ganti Sandi
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 max-h-[75vh] overflow-y-auto">
          {tab === 'login' && (
            <div className="space-y-4">
              {/* Jika sedang login, tampilkan sesi aktif dan tombol logout */}
              {activeUser && (
                <div className={`p-3.5 rounded-2xl border ${
                  isDark ? 'bg-slate-800/60 border-slate-700' : 'bg-emerald-50/70 border-emerald-200'
                }`}>
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <img
                        src={activeUser.avatar}
                        alt={activeUser.name}
                        className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500 shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-bold truncate">{activeUser.name}</p>
                          {activeUser.role === 'admin' ? (
                            <span className="text-[9px] bg-amber-500/15 text-amber-500 border border-amber-500/30 px-1.5 py-0.5 rounded font-bold">
                              Admin
                            </span>
                          ) : (
                            <span className="text-[9px] bg-emerald-500/15 text-emerald-600 border border-emerald-500/30 px-1.5 py-0.5 rounded font-medium">
                              Pengguna
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] opacity-70 truncate">
                          @{activeUser.username} • Sesi Aktif
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      id="btn-logout-auth-modal"
                      onClick={() => {
                        onSelectUser(null);
                        onClose();
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white transition-colors shrink-0 shadow-2xs"
                    >
                      <LogOut size={13} />
                      <span>Keluar</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Login with Credential Form */}
              <div className="space-y-3">
                <p className="text-xs font-semibold opacity-80">
                  {activeUser ? 'Atau beralih ke akun lain:' : 'Masukkan username dan kata sandi Anda:'}
                </p>

                {loginError && (
                  <div className={`p-2.5 border text-xs rounded-xl flex items-center gap-1.5 ${
                    isDark
                      ? 'bg-rose-950/50 border-rose-900 text-rose-300'
                      : 'bg-rose-50 border-rose-200 text-rose-700'
                  }`}>
                    <AlertCircle size={14} className="shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-3">
                  <div>
                    <label className="text-xs font-bold block mb-1">Username / Email</label>
                    <input
                      type="text"
                      id="input-login-identifier"
                      value={loginIdentifier}
                      onChange={e => setLoginIdentifier(e.target.value)}
                      placeholder="Masukkan username atau email Anda"
                      required
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs outline-none ${
                        isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold block mb-1">Kata Sandi / PIN</label>
                    <input
                      type="password"
                      id="input-login-pin"
                      value={loginPin}
                      onChange={e => setLoginPin(e.target.value)}
                      placeholder="Masukkan kata sandi"
                      required
                      className={`w-full px-3.5 py-2.5 rounded-xl border text-xs outline-none ${
                        isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                      }`}
                    />
                  </div>
                  <button
                    type="submit"
                    id="btn-submit-login"
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-2xs flex items-center justify-center gap-1.5"
                  >
                    <LogIn size={14} />
                    <span>Masuk ke Akun</span>
                  </button>
                </form>

                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={() => { setTab('signup'); setSignupError(''); }}
                    className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
                  >
                    Belum punya akun? Buat Akun Baru (Mulai Kosong) &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}

          {tab === 'signup' && (
            <form onSubmit={handleSignup} className="space-y-3.5">
              {signupError && (
                <div className={`p-2.5 border text-xs rounded-xl flex items-center gap-1.5 ${
                  isDark
                    ? 'bg-rose-950/50 border-rose-900 text-rose-300'
                    : 'bg-rose-50 border-rose-200 text-rose-700'
                }`}>
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{signupError}</span>
                </div>
              )}

              {/* Photo Profile Selection + Gallery Upload */}
              <div>
                <label className="text-xs font-semibold block mb-1.5">
                  Foto Profil:
                </label>
                <div className="flex items-center gap-3">
                  {/* Active Preview */}
                  <div className="relative group shrink-0">
                    <img
                      src={selectedAvatar}
                      alt="Avatar Preview"
                      className="w-14 h-14 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity"
                      title="Ganti dari galeri"
                    >
                      <Camera size={16} />
                    </button>
                  </div>

                  <div className="flex-1 space-y-2">
                    {/* Gallery upload button */}
                    <div>
                      <input
                        type="file"
                        ref={fileInputRef}
                        accept="image/*"
                        onChange={handleGalleryUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        id="btn-upload-gallery"
                        onClick={() => fileInputRef.current?.click()}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                          isDark
                            ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <Upload size={13} className="text-emerald-600" />
                        Pilih dari Galeri Foto
                      </button>
                    </div>

                    {/* Preset Avatars Row */}
                    <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                      {PRESET_AVATARS.map((av, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSelectedAvatar(av)}
                          className={`w-7 h-7 rounded-full overflow-hidden border-2 shrink-0 transition-transform ${
                            selectedAvatar === av ? 'border-emerald-500 scale-110' : 'border-transparent opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img src={av} alt="Preset" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Nama Lengkap */}
              <div>
                <label className="text-xs font-semibold block mb-1">
                  Nama Lengkap *
                </label>
                <input
                  type="text"
                  required
                  id="input-signup-name"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Contoh: Rian Anggara"
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              {/* Username Unik */}
              <div>
                <label className="text-xs font-semibold block mb-1">
                  Username * <span className="opacity-60 font-normal">(Tidak boleh sama dengan akun lain)</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2 text-slate-400 font-bold text-xs">@</span>
                  <input
                    type="text"
                    required
                    id="input-signup-username"
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="rian_anggara"
                    className={`w-full pl-8 pr-3.5 py-2 rounded-xl border text-xs outline-none ${
                      isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                    }`}
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="text-xs font-semibold block mb-1">
                  Email Akun
                </label>
                <input
                  type="email"
                  id="input-signup-email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="rian@example.com"
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              {/* Sandi / PIN */}
              <div>
                <label className="text-xs font-semibold block mb-1">
                  Sandi / PIN Akun
                </label>
                <input
                  type="password"
                  id="input-signup-pin"
                  value={pin}
                  onChange={e => setPin(e.target.value)}
                  placeholder="Contoh: 1234 atau kata sandi Anda"
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              {/* Mata Uang & Budget */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold block mb-1">
                    Mata Uang
                  </label>
                  <select
                    id="select-signup-currency"
                    value={currency}
                    onChange={e => setCurrency(e.target.value as any)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                      isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                    }`}
                  >
                    <option value="IDR">IDR (Rp)</option>
                    <option value="USD">USD ($)</option>
                    <option value="MYR">MYR (RM)</option>
                    <option value="SGD">SGD (S$)</option>
                    <option value="EUR">EUR (€)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold block mb-1">
                    Budget Bulanan
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="100000"
                    id="input-signup-budget"
                    value={monthlyBudget}
                    onChange={e => setMonthlyBudget(e.target.value)}
                    className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                      isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                    }`}
                  />
                </div>
              </div>

              <button
                type="submit"
                id="btn-submit-signup"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-2xs mt-2"
              >
                Daftarkan Akun
              </button>
            </form>
          )}

          {tab === 'reset' && (
            <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5">
              <p className="text-xs opacity-70">
                Masukkan username atau email Anda untuk memperbarui sandi / PIN keamanan.
              </p>

              {resetMessage && (
                <div className={`p-2.5 rounded-xl text-xs flex items-center gap-1.5 border ${
                  resetMessage.type === 'success'
                    ? isDark
                      ? 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
                      : 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : isDark
                    ? 'bg-rose-950/50 border-rose-900 text-rose-300'
                    : 'bg-rose-50 border-rose-200 text-rose-700'
                }`}>
                  {resetMessage.type === 'success' ? (
                    <CheckCircle2 size={14} className="shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle size={14} className="shrink-0 text-rose-600" />
                  )}
                  <span>{resetMessage.text}</span>
                </div>
              )}

              <div>
                <label className="text-xs font-semibold block mb-1">
                  Username atau Email Terdaftar
                </label>
                <input
                  type="text"
                  required
                  id="input-reset-identifier"
                  value={resetIdentifier}
                  onChange={e => setResetIdentifier(e.target.value)}
                  placeholder="Username / email"
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">
                  Sandi Baru (Minimal 4 karakter)
                </label>
                <input
                  type="password"
                  required
                  id="input-reset-new-password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="Sandi baru..."
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              <div>
                <label className="text-xs font-semibold block mb-1">
                  Konfirmasi Sandi Baru
                </label>
                <input
                  type="password"
                  required
                  id="input-reset-confirm-password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Ulangi sandi baru..."
                  className={`w-full px-3.5 py-2 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200'
                  }`}
                />
              </div>

              <button
                type="submit"
                id="btn-submit-reset-password"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-2xs"
              >
                Perbarui Sandi
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
