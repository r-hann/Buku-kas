import React, { useState, useEffect } from 'react';
import { CategoryItem, ColorMode, PaymentMethod, ThemeConfig, Transaction, TransactionType } from '../types';
import { formatCurrency } from '../utils/formatters';
import { CategoryIcon } from './CategoryIcon';
import { X, Calendar, Clock, FileText, Check, Plus, Minus } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Omit<Transaction, 'id' | 'createdAt'>, editId?: string) => void;
  categories: CategoryItem[];
  theme: ThemeConfig;
  colorMode: ColorMode;
  currency: string;
  initialData?: Transaction | null;
  userId: string;
}

const PAYMENT_METHODS: { id: PaymentMethod; label: string }[] = [
  { id: 'qris', label: 'QRIS' },
  { id: 'cash', label: 'Tunai' },
  { id: 'transfer', label: 'Transfer Bank' },
  { id: 'ewallet', label: 'e-Wallet' },
  { id: 'card', label: 'Kartu' },
];

const QUICK_AMOUNTS = [10000, 25000, 50000, 100000, 250000, 500000];

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  categories,
  theme,
  colorMode,
  currency,
  initialData,
  userId,
}) => {
  const [type, setType] = useState<TransactionType>('expense');
  const [amountStr, setAmountStr] = useState('');
  const [category, setCategory] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('qris');
  const [note, setNote] = useState('');
  const [error, setError] = useState('');

  const isDark = colorMode === 'dark';

  useEffect(() => {
    if (initialData) {
      setType(initialData.type);
      setAmountStr(initialData.amount.toString());
      setCategory(initialData.category);
      setDate(initialData.date);
      setTime(initialData.time || '12:00');
      setPaymentMethod(initialData.paymentMethod);
      setNote(initialData.note || '');
    } else {
      const now = new Date();
      setType('expense');
      setAmountStr('');
      setDate(now.toISOString().slice(0, 10));
      setTime(now.toTimeString().slice(0, 5));
      setPaymentMethod('qris');
      setNote('');
      setError('');

      const defaultCats = categories.filter(c => c.type === 'expense');
      if (defaultCats.length > 0) {
        setCategory(defaultCats[0].name);
      }
    }
  }, [initialData, isOpen, categories]);

  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    const available = categories.filter(c => c.type === newType);
    if (available.length > 0) {
      setCategory(available[0].name);
    }
  };

  if (!isOpen) return null;

  const currentCategories = categories.filter(c => c.type === type);
  const numericAmount = parseFloat(amountStr) || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!numericAmount || numericAmount <= 0) {
      setError('Masukkan nominal transaksi yang valid (lebih dari 0).');
      return;
    }
    if (!category) {
      setError('Pilih kategori transaksi.');
      return;
    }

    onSave(
      {
        userId,
        type,
        amount: numericAmount,
        category,
        date,
        time,
        paymentMethod,
        note: note.trim(),
      },
      initialData?.id
    );

    if (!initialData) {
      confetti({
        particleCount: 50,
        spread: 50,
        origin: { y: 0.6 },
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
      <div
        id="transaction-modal-card"
        className={`rounded-3xl shadow-2xl border w-full max-w-lg overflow-hidden relative ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className={`p-5 text-white ${type === 'expense' ? 'bg-rose-600' : 'bg-emerald-600'} transition-colors relative`}>
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X size={18} />
          </button>

          <div className="flex items-center justify-between pr-8">
            <h2 className="text-base font-bold">
              {initialData ? 'Edit Transaksi' : 'Catat Transaksi Baru'}
            </h2>
          </div>

          {/* Type Toggle */}
          <div className="flex bg-black/20 p-1 rounded-xl mt-3 max-w-xs text-xs">
            <button
              type="button"
              id="btn-tx-type-expense"
              onClick={() => handleTypeChange('expense')}
              className={`flex-1 py-1.5 font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                type === 'expense' ? 'bg-white text-rose-700 shadow-xs' : 'text-white/80 hover:text-white'
              }`}
            >
              <Minus size={13} />
              Pengeluaran (-)
            </button>
            <button
              type="button"
              id="btn-tx-type-income"
              onClick={() => handleTypeChange('income')}
              className={`flex-1 py-1.5 font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                type === 'income' ? 'bg-white text-emerald-700 shadow-xs' : 'text-white/80 hover:text-white'
              }`}
            >
              <Plus size={13} />
              Pemasukan (+)
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className={`p-3 border text-xs rounded-xl ${
              isDark
                ? 'bg-rose-950/50 border-rose-900 text-rose-300'
                : 'bg-rose-50 border-rose-200 text-rose-700'
            }`}>
              {error}
            </div>
          )}

          {/* Amount Input */}
          <div>
            <label className="text-xs font-bold block mb-1 opacity-80">
              Nominal ({currency}) *
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 font-bold text-base opacity-40">
                {currency === 'IDR' ? 'Rp' : currency}
              </span>
              <input
                type="number"
                step="any"
                min="0"
                required
                id="input-tx-amount"
                value={amountStr}
                onChange={e => setAmountStr(e.target.value)}
                placeholder="0"
                className={`w-full pl-12 pr-3.5 py-2.5 rounded-xl border text-xl font-extrabold outline-none focus:ring-2 focus:ring-emerald-500/20 ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-white focus:border-emerald-500'
                    : 'bg-white border-slate-200 text-slate-900 focus:border-emerald-500'
                }`}
              />
            </div>

            {/* Quick nominal chips */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {QUICK_AMOUNTS.map(amt => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmountStr(amt.toString())}
                  className={`px-2 py-0.8 text-[11px] rounded-lg border font-semibold transition-colors ${
                    isDark
                      ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                  }`}
                >
                  +{amt >= 1000 ? `${amt / 1000}rb` : amt}
                </button>
              ))}
            </div>
          </div>

          {/* Category Selector */}
          <div>
            <label className="text-xs font-bold block mb-1.5 opacity-80">
              Kategori Transaksi *
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-40 overflow-y-auto p-1">
              {currentCategories.map(cat => {
                const isSelected = category === cat.name;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.name)}
                    className={`p-2 rounded-xl border text-left flex flex-col items-center gap-1 transition-all ${
                      isSelected
                        ? isDark
                          ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300 ring-2 ring-emerald-500/20'
                          : 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-600/20'
                        : isDark
                        ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40 text-slate-300'
                        : 'border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-white"
                      style={{ backgroundColor: cat.color }}
                    >
                      <CategoryIcon iconName={cat.icon} size={14} />
                    </div>
                    <span className="text-[10px] font-semibold text-center line-clamp-1 w-full">
                      {cat.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold block mb-1 opacity-80 flex items-center gap-1">
                <Calendar size={13} /> Tanggal
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1 opacity-80 flex items-center gap-1">
                <Clock size={13} /> Waktu
              </label>
              <input
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="text-xs font-bold block mb-1 opacity-80">
              Metode Pembayaran
            </label>
            <div className="flex flex-wrap gap-1.5">
              {PAYMENT_METHODS.map(m => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setPaymentMethod(m.id)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-colors ${
                    paymentMethod === m.id
                      ? isDark
                        ? 'bg-emerald-950/70 border-emerald-500 text-emerald-300'
                        : 'bg-emerald-600 border-emerald-600 text-white shadow-2xs'
                      : isDark
                      ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-bold block mb-1 opacity-80 flex items-center gap-1">
              <FileText size={13} /> Catatan / Keterangan
            </label>
            <input
              type="text"
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Contoh: Makan siang bareng rekan kerja"
              className={`w-full px-3 py-2 rounded-xl border text-xs outline-none ${
                isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            />
          </div>

          {/* Action Button */}
          <button
            type="submit"
            id="btn-save-transaction"
            className={`w-full py-2.5 rounded-xl text-white font-bold text-xs shadow-xs transition-all ${
              type === 'expense' ? 'bg-rose-600 hover:bg-rose-700' : 'bg-emerald-600 hover:bg-emerald-700'
            }`}
          >
            {initialData ? 'Simpan Perubahan' : 'Catat Transaksi Sekarang'}
          </button>
        </form>
      </div>
    </div>
  );
};
