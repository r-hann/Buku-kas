import React, { useState, useRef } from 'react';
import { ColorMode, NavPosition, PlusButtonPosition, ThemeConfig, ThemePreset, UserAccount } from '../types';
import { DEFAULT_THEMES } from '../utils/constants';
import {
  Palette, Check, DollarSign, Wallet, ShieldAlert, RotateCcw,
  Sun, Moon, Layout, PlusCircle, KeyRound, User, Camera, Upload, AlertCircle
} from 'lucide-react';
import { formatCurrency } from '../utils/formatters';

interface ThemeCustomizerProps {
  currentTheme: ThemePreset;
  onSelectTheme: (theme: ThemePreset) => void;
  colorMode: ColorMode;
  onToggleColorMode: (mode: ColorMode) => void;
  navPosition: NavPosition;
  onSelectNavPosition: (pos: NavPosition) => void;
  plusButtonPosition: PlusButtonPosition;
  onSelectPlusButtonPosition: (pos: PlusButtonPosition) => void;
  activeUser: UserAccount | null;
  users: UserAccount[];
  onUpdateUser: (updated: Partial<UserAccount>) => void;
  onResetData: () => void;
  onOpenResetPasswordModal: () => void;
}

export const ThemeCustomizer: React.FC<ThemeCustomizerProps> = ({
  currentTheme,
  onSelectTheme,
  colorMode,
  onToggleColorMode,
  navPosition,
  onSelectNavPosition,
  plusButtonPosition,
  onSelectPlusButtonPosition,
  activeUser,
  users,
  onUpdateUser,
  onResetData,
  onOpenResetPasswordModal,
}) => {
  // Profile settings
  const [profileName, setProfileName] = useState(activeUser?.name || '');
  const [profileUsername, setProfileUsername] = useState(activeUser?.username || '');
  const [profileAvatar, setProfileAvatar] = useState(activeUser?.avatar || '');
  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');

  // Financial settings
  const [budgetInput, setBudgetInput] = useState(
    activeUser?.monthlyBudget?.toString() || '4000000'
  );
  const [currencyVal, setCurrencyVal] = useState(activeUser?.currency || 'IDR');
  const [financeSaveMessage, setFinanceSaveMessage] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isDark = colorMode === 'dark';

  // Handle gallery upload for active profile
  const handleAvatarGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      setProfileError('Ukuran gambar terlalu besar. Maksimal 3 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (evt) => {
      const result = evt.target?.result as string;
      if (result) {
        setProfileAvatar(result);
        onUpdateUser({ avatar: result });
        setProfileSuccess('Foto profil berhasil diperbarui dari galeri.');
        setTimeout(() => setProfileSuccess(''), 3000);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError('');
    setProfileSuccess('');

    if (!activeUser) return;
    const cleanName = profileName.trim();
    const cleanUsername = profileUsername.trim().toLowerCase().replace(/\s+/g, '_');

    if (!cleanName) {
      setProfileError('Nama lengkap wajib diisi.');
      return;
    }

    if (!cleanUsername) {
      setProfileError('Username wajib diisi.');
      return;
    }

    // Check if new username is unique among other users
    const isTaken = users.some(u => u.id !== activeUser.id && u.username.toLowerCase() === cleanUsername);
    if (isTaken) {
      setProfileError(`Username @${cleanUsername} sudah digunakan oleh akun lain. Silakan pilih username berbeda.`);
      return;
    }

    onUpdateUser({
      name: cleanName,
      username: cleanUsername,
      avatar: profileAvatar,
    });

    setProfileSuccess('Profil berhasil diperbarui.');
    setTimeout(() => setProfileSuccess(''), 3000);
  };

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUser) return;
    const num = parseFloat(budgetInput) || 0;
    onUpdateUser({
      monthlyBudget: num,
      currency: currencyVal as any,
    });
    setFinanceSaveMessage('Preferensi finansial berhasil disimpan.');
    setTimeout(() => setFinanceSaveMessage(''), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* 1. Profil Pengguna (Edit Nama, Username Unik & Foto Galeri) */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <User className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Profil Pengguna Aktif
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Kelola foto profil dari galeri HP/laptop serta username unik akun Anda.
        </p>

        {profileError && (
          <div className={`p-3 mb-4 border text-xs rounded-xl flex items-center gap-2 ${
            isDark
              ? 'bg-rose-950/50 border-rose-900 text-rose-300'
              : 'bg-rose-50 border-rose-200 text-rose-700'
          }`}>
            <AlertCircle size={15} className="shrink-0" />
            <span>{profileError}</span>
          </div>
        )}

        {profileSuccess && (
          <div className={`p-3 mb-4 border text-xs rounded-xl flex items-center gap-2 ${
            isDark
              ? 'bg-emerald-950/50 border-emerald-800 text-emerald-300'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
          }`}>
            <Check size={15} className="text-emerald-600 shrink-0" />
            <span>{profileSuccess}</span>
          </div>
        )}

        <form onSubmit={handleSaveProfile} className="space-y-4 max-w-lg">
          {/* Avatar Upload with Gallery */}
          <div className="flex items-center gap-4">
            <div className="relative group shrink-0">
              <img
                src={profileAvatar || activeUser?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'}
                alt={activeUser?.name || 'User'}
                className="w-16 h-16 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/40 rounded-full opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity"
                title="Pilih dari galeri"
              >
                <Camera size={18} />
              </button>
            </div>

            <div>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handleAvatarGalleryUpload}
                className="hidden"
              />
              <button
                type="button"
                id="btn-edit-avatar-gallery"
                onClick={() => fileInputRef.current?.click()}
                className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 shadow-2xs ${
                  isDark
                    ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-750'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Upload size={13} className="text-emerald-600" />
                Pilih Foto dari Galeri
              </button>
              <p className="text-[11px] opacity-60 mt-1">
                Format JPG/PNG, ukuran maksimal 3 MB.
              </p>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              Nama Lengkap
            </label>
            <input
              type="text"
              value={profileName}
              onChange={e => setProfileName(e.target.value)}
              placeholder="Nama Lengkap"
              className={`w-full px-3.5 py-2 rounded-xl border text-xs font-medium outline-none ${
                isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            />
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              Username Unik
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2 text-slate-400 font-bold text-xs">@</span>
              <input
                type="text"
                value={profileUsername}
                onChange={e => setProfileUsername(e.target.value)}
                placeholder="username"
                className={`w-full pl-8 pr-3.5 py-2 rounded-xl border text-xs font-medium outline-none ${
                  isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
                }`}
              />
            </div>
          </div>

          <button
            type="submit"
            id="btn-save-profile"
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-2xs transition-colors"
          >
            Simpan Perubahan Profil
          </button>
        </form>
      </div>

      {/* 2. Dark / Light Mode Selector */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            {isDark ? <Moon className="text-amber-400" size={18} /> : <Sun className="text-amber-500" size={18} />}
            <h3 className="text-base font-bold tracking-tight">
              Mode Tampilan (Dark / Light Mode)
            </h3>
          </div>
          <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${
            isDark
              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
          }`}>
            {isDark ? 'Mode Gelap' : 'Mode Terang'}
          </span>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Sesuaikan kenyamanan membaca Anda antara kontras terang atau gelap malam.
        </p>

        <div className="grid grid-cols-2 gap-3 max-w-md">
          <button
            type="button"
            id="btn-mode-light"
            onClick={() => onToggleColorMode('light')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              colorMode === 'light'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/40 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                <Sun size={18} />
              </div>
              <div>
                <p className={`text-xs font-bold ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>Terang</p>
                <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Bersih & tajam</p>
              </div>
            </div>
            {colorMode === 'light' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>

          <button
            type="button"
            id="btn-mode-dark"
            onClick={() => onToggleColorMode('dark')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              colorMode === 'dark'
                ? isDark
                  ? 'border-emerald-500 bg-slate-800 shadow-2xs'
                  : 'border-emerald-600 bg-slate-800 text-white shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-indigo-950 text-amber-300 flex items-center justify-center shrink-0">
                <Moon size={18} />
              </div>
              <div>
                <p className={`text-xs font-bold ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>Gelap</p>
                <p className={`text-[11px] ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Ramah mata</p>
              </div>
            </div>
            {colorMode === 'dark' && (
              <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* 3. Posisi Tab Navigasi */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <Layout className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Posisi Tab Navigasi Menu
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Pilih lokasi menu tab: di bawah layar (gaya aplikasi mobile) atau di bilah header atas.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg">
          <button
            type="button"
            id="btn-nav-bottom"
            onClick={() => onSelectNavPosition('bottom')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              navPosition === 'bottom'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <p className="text-xs font-bold">Menu Bawah (Dock Aplikasi)</p>
              <p className="text-[11px] opacity-60">Mudah dijangkau ibu jari</p>
            </div>
            {navPosition === 'bottom' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>

          <button
            type="button"
            id="btn-nav-top"
            onClick={() => onSelectNavPosition('top')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              navPosition === 'top'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <p className="text-xs font-bold">Menu Atas (Header Standar)</p>
              <p className="text-[11px] opacity-60">Menyatu di bilah atas aplikasi</p>
            </div>
            {navPosition === 'top' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* 4. Posisi Tombol Tambah (+) */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <PlusCircle className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Posisi Tombol Catat Transaksi (+)
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Posisikan tombol (+) sesuai kebiasaan penggunaan satu tangan Anda.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            type="button"
            id="btn-plus-bottom-center"
            onClick={() => onSelectPlusButtonPosition('bottom-center')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              plusButtonPosition === 'bottom-center'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <p className="text-xs font-bold">Tengah Bawah</p>
              <p className="text-[11px] opacity-60">Pusat bilah bawah</p>
            </div>
            {plusButtonPosition === 'bottom-center' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>

          <button
            type="button"
            id="btn-plus-bottom-right"
            onClick={() => onSelectPlusButtonPosition('bottom-right')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              plusButtonPosition === 'bottom-right'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <p className="text-xs font-bold">Kanan Bawah (FAB)</p>
              <p className="text-[11px] opacity-60">Melayang di sudut</p>
            </div>
            {plusButtonPosition === 'bottom-right' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>

          <button
            type="button"
            id="btn-plus-topbar"
            onClick={() => onSelectPlusButtonPosition('topbar')}
            className={`p-3.5 rounded-2xl border-2 text-left flex items-center justify-between transition-all ${
              plusButtonPosition === 'topbar'
                ? isDark
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                  : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                : isDark
                ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                : 'border-slate-200 hover:border-slate-300 bg-slate-50'
            }`}
          >
            <div>
              <p className="text-xs font-bold">Header Atas</p>
              <p className="text-[11px] opacity-60">Di samping profil</p>
            </div>
            {plusButtonPosition === 'topbar' && (
              <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                <Check size={12} />
              </div>
            )}
          </button>
        </div>
      </div>

      {/* 5. Palet Warna Aksen */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <Palette className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Pilihan Warna Aksen
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Warna utama untuk tombol, status saldo, dan elemen aksen grafis.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(Object.keys(DEFAULT_THEMES) as ThemePreset[]).map(key => {
            const t = DEFAULT_THEMES[key];
            const isSelected = currentTheme === key;

            return (
              <button
                key={key}
                type="button"
                id={`theme-btn-${key}`}
                onClick={() => onSelectTheme(key)}
                className={`p-3.5 rounded-2xl border-2 text-left transition-all flex flex-col justify-between gap-3 ${
                  isSelected
                    ? isDark
                      ? 'border-emerald-500 bg-emerald-950/30 shadow-2xs'
                      : 'border-emerald-600 bg-emerald-50/70 shadow-2xs'
                    : isDark
                    ? 'border-slate-800 hover:border-slate-700 bg-slate-800/40'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold">{t.name}</span>
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                      <Check size={12} />
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1.5 pt-1">
                  <div className={`h-4 flex-1 rounded-lg bg-gradient-to-r ${t.gradient}`} />
                  <div
                    className="w-4 h-4 rounded-lg shrink-0 border border-black/10"
                    style={{ backgroundColor: t.accent }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6. Pengaturan Anggaran & Mata Uang */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <Wallet className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Target Anggaran & Mata Uang
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Atur batas pengeluaran bulanan dan format mata uang akun.
        </p>

        {financeSaveMessage && (
          <div className={`p-3 mb-4 border text-xs rounded-xl flex items-center gap-2 ${
            isDark
              ? 'bg-emerald-950 border-emerald-800 text-emerald-300'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
          }`}>
            <Check size={16} className="text-emerald-600" />
            <span>{financeSaveMessage}</span>
          </div>
        )}

        <form onSubmit={handleSavePreferences} className="space-y-4 max-w-lg">
          <div>
            <label className="text-xs font-bold block mb-1">
              Mata Uang
            </label>
            <select
              value={currencyVal}
              onChange={e => setCurrencyVal(e.target.value as any)}
              className={`w-full px-3.5 py-2 rounded-xl border text-xs font-semibold outline-none ${
                isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <option value="IDR">Rupiah Indonesia (Rp / IDR)</option>
              <option value="USD">US Dollar ($ / USD)</option>
              <option value="MYR">Ringgit Malaysia (RM / MYR)</option>
              <option value="SGD">Singapore Dollar (S$ / SGD)</option>
              <option value="EUR">Euro (€ / EUR)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold block mb-1">
              Batas Anggaran Bulanan
            </label>
            <input
              type="number"
              min="0"
              step="50000"
              value={budgetInput}
              onChange={e => setBudgetInput(e.target.value)}
              className={`w-full px-3.5 py-2 rounded-xl border text-xs font-semibold outline-none ${
                isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
            />
            <p className="text-[11px] opacity-60 mt-1">
              Batas budget: {formatCurrency(parseFloat(budgetInput) || 0, currencyVal)}
            </p>
          </div>

          <button
            type="submit"
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-2xs transition-colors"
          >
            Simpan Anggaran
          </button>
        </form>
      </div>

      {/* 7. Reset Sandi Akun */}
      <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        <div className="flex items-center gap-2 mb-2">
          <KeyRound className={isDark ? 'text-slate-400' : 'text-slate-500'} size={18} />
          <h3 className="text-base font-bold tracking-tight">
            Keamanan Sandi Akun
          </h3>
        </div>
        <p className="text-xs opacity-70 mb-4">
          Perbarui PIN atau kata sandi akun Anda secara langsung.
        </p>
        <button
          type="button"
          id="btn-open-reset-password-dialog"
          onClick={onOpenResetPasswordModal}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-xl transition-colors shadow-2xs ${
            isDark
              ? 'bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white'
          }`}
        >
          <KeyRound size={14} />
          Buka Form Ganti Sandi
        </button>
      </div>

      {/* 8. Reset Data Ke Setelan Awal */}
      <div className={`rounded-2xl border p-5 ${
        isDark ? 'bg-rose-950/20 border-rose-900/50 text-rose-200' : 'bg-rose-50/70 border-rose-200 text-rose-950'
      }`}>
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5">
            <ShieldAlert size={16} />
          </div>
          <div className="space-y-2">
            <h4 className={`text-sm font-bold ${isDark ? 'text-rose-400' : 'text-rose-700'}`}>
              Reset Data BukuKas
            </h4>
            <p className="text-xs opacity-80 leading-relaxed">
              Mengembalikan transaksi, kategori, dan pengaturan ke data awal.
            </p>
            <button
              type="button"
              id="btn-reset-demo-data"
              onClick={onResetData}
              className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white transition-colors"
            >
              <RotateCcw size={13} />
              Reset Data Awal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
