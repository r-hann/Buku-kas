import React, { useState, useMemo } from 'react';
import { ColorMode, ThemeConfig, Transaction } from '../types';
import { formatCurrency } from '../utils/formatters';
import { CategoryIcon } from './CategoryIcon';
import { TrendingDown, TrendingUp, PieChart as PieIcon, BarChart2 } from 'lucide-react';

interface ChartsProps {
  transactions: Transaction[];
  categoriesMap: Map<string, { icon: string; color: string }>;
  theme: ThemeConfig;
  colorMode: ColorMode;
  currency: string;
}

export const Charts: React.FC<ChartsProps> = ({ transactions, categoriesMap, theme, colorMode, currency }) => {
  const [activeSegment, setActiveSegment] = useState<string | null>(null);
  const [chartType, setChartType] = useState<'donut' | 'bars'>('donut');

  const isDark = colorMode === 'dark';

  // Filter only expenses for category breakdown
  const expenseData = useMemo(() => {
    const expenses = transactions.filter(t => t.type === 'expense');
    const total = expenses.reduce((acc, t) => acc + t.amount, 0);

    const byCat: Record<string, number> = {};
    expenses.forEach(t => {
      byCat[t.category] = (byCat[t.category] || 0) + t.amount;
    });

    const items = Object.entries(byCat)
      .map(([name, amount]) => {
        const catInfo = categoriesMap.get(name) || { icon: 'CircleDollarSign', color: '#94a3b8' };
        const percentage = total > 0 ? (amount / total) * 100 : 0;
        return {
          name,
          amount,
          percentage,
          color: catInfo.color,
          icon: catInfo.icon,
        };
      })
      .sort((a, b) => b.amount - a.amount);

    return { total, items };
  }, [transactions, categoriesMap]);

  // Daily trend data for last 7 days with transactions
  const trendData = useMemo(() => {
    const datesMap: Record<string, { expense: number; income: number }> = {};
    
    // Last 7 days
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      datesMap[key] = { expense: 0, income: 0 };
    }

    transactions.forEach(t => {
      if (datesMap[t.date]) {
        if (t.type === 'expense') {
          datesMap[t.date].expense += t.amount;
        } else {
          datesMap[t.date].income += t.amount;
        }
      }
    });

    const entries = Object.entries(datesMap).map(([date, val]) => {
      const parts = date.split('-');
      const label = `${parts[2]}/${parts[1]}`;
      return {
        date,
        label,
        expense: val.expense,
        income: val.income,
      };
    });

    const maxVal = Math.max(
      ...entries.map(e => Math.max(e.expense, e.income)),
      100000
    );

    return { entries, maxVal };
  }, [transactions]);

  // Donut SVG Calculations
  const radius = 68;
  const strokeWidth = 26;
  const circumference = 2 * Math.PI * radius;
  let cumulativePercent = 0;

  const activeItem = activeSegment ? expenseData.items.find(i => i.name === activeSegment) : null;

  return (
    <div
      id="analytics-charts-card"
      className={`rounded-2xl border p-5 shadow-xs transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200/80 text-slate-800'
      }`}
    >
      {/* Header controls */}
      <div className={`flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b ${
        isDark ? 'border-slate-800' : 'border-slate-100'
      }`}>
        <div>
          <h3 className="text-base font-bold flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${theme.primary}`}></span>
            Visualisasi & Analisis Grafik
          </h3>
          <p className="text-xs opacity-60 mt-0.5">
            Komposisi pengeluaran dan tren keuangan harian
          </p>
        </div>

        <div className={`flex items-center gap-1 p-1 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
          <button
            type="button"
            id="btn-toggle-donut"
            onClick={() => setChartType('donut')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              chartType === 'donut'
                ? isDark
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <PieIcon size={14} />
            Kategori
          </button>
          <button
            type="button"
            id="btn-toggle-bars"
            onClick={() => setChartType('bars')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              chartType === 'bars'
                ? isDark
                  ? 'bg-slate-700 text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <BarChart2 size={14} />
            Tren 7 Hari
          </button>
        </div>
      </div>

      {chartType === 'donut' ? (
        expenseData.items.length === 0 ? (
          <div className="py-12 text-center opacity-50 text-xs">
            Belum ada catatan pengeluaran untuk ditampilkan dalam diagram lingkaran.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            {/* SVG Donut Visual */}
            <div className="md:col-span-5 flex flex-col items-center justify-center relative">
              <div className="relative w-48 h-48 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 190 190">
                  <circle
                    cx="95"
                    cy="95"
                    r={radius}
                    className={isDark ? 'stroke-slate-800' : 'stroke-slate-100'}
                    strokeWidth={strokeWidth}
                    fill="transparent"
                  />
                  {expenseData.items.map(item => {
                    const strokeDasharray = `${(item.percentage / 100) * circumference} ${circumference}`;
                    const strokeDashoffset = -((cumulativePercent / 100) * circumference);
                    cumulativePercent += item.percentage;
                    const isHovered = activeSegment === item.name;

                    return (
                      <circle
                        key={item.name}
                        cx="95"
                        cy="95"
                        r={radius}
                        stroke={item.color}
                        strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        fill="transparent"
                        className="cursor-pointer transition-all duration-300"
                        onMouseEnter={() => setActiveSegment(item.name)}
                        onMouseLeave={() => setActiveSegment(null)}
                      />
                    );
                  })}
                </svg>

                {/* Donut Center text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 pointer-events-none">
                  {activeItem ? (
                    <>
                      <span className="text-[10px] font-bold opacity-60 uppercase truncate max-w-[90px]">
                        {activeItem.name}
                      </span>
                      <span className={`text-xs font-extrabold mt-0.5 ${isDark ? 'text-rose-400' : 'text-rose-600'}`}>
                        {formatCurrency(activeItem.amount, currency)}
                      </span>
                      <span className="text-[11px] font-bold mt-0.5">
                        {activeItem.percentage.toFixed(1)}%
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="text-[10px] font-medium opacity-50 uppercase tracking-wider">
                        Total Keluar
                      </span>
                      <span className="text-xs font-extrabold mt-0.5">
                        {formatCurrency(expenseData.total, currency)}
                      </span>
                      <span className="text-[10px] opacity-60 mt-0.5">
                        {expenseData.items.length} Kategori
                      </span>
                    </>
                  )}
                </div>
              </div>

              <span className="text-[11px] opacity-50 mt-2">
                Sentuh atau arahkan ke lingkaran untuk detail
              </span>
            </div>

            {/* Category breakdown listing */}
            <div className="md:col-span-7 space-y-2 max-h-64 overflow-y-auto pr-1">
              {expenseData.items.map(item => {
                const isHovered = activeSegment === item.name;
                return (
                  <div
                    key={item.name}
                    id={`cat-stat-${item.name.replace(/\s+/g, '-').toLowerCase()}`}
                    onMouseEnter={() => setActiveSegment(item.name)}
                    onMouseLeave={() => setActiveSegment(null)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                      isHovered
                        ? isDark
                          ? 'border-slate-700 bg-slate-800 translate-x-1 shadow-xs'
                          : 'border-slate-300 bg-slate-50/80 translate-x-1 shadow-xs'
                        : isDark
                        ? 'border-slate-800 bg-slate-850/50 hover:border-slate-700'
                        : 'border-slate-100 hover:border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white shrink-0 shadow-2xs"
                        style={{ backgroundColor: item.color }}
                      >
                        <CategoryIcon name={item.icon} size={16} />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate">{item.name}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <div className={`w-16 h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
                            <div
                              className="h-full rounded-full transition-all duration-500"
                              style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                            />
                          </div>
                          <span className="text-[10px] opacity-70 font-medium">
                            {item.percentage.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-xs font-bold">
                        {formatCurrency(item.amount, currency)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )
      ) : (
        /* Trend Bar Chart */
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs opacity-70">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-emerald-500"></span>
                Pemasukan
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-rose-500"></span>
                Pengeluaran
              </span>
            </div>
            <span>7 Hari Terakhir</span>
          </div>

          <div className={`h-44 flex items-end justify-between gap-2 pt-6 pb-2 px-2 border-b ${
            isDark ? 'border-slate-800' : 'border-slate-100'
          }`}>
            {trendData.entries.map((day, idx) => {
              const expPercent = Math.min((day.expense / trendData.maxVal) * 100, 100);
              const incPercent = Math.min((day.income / trendData.maxVal) * 100, 100);

              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-12 left-1/2 -translate-x-1/2 z-20 pointer-events-none bg-slate-900 text-white text-[10px] rounded-lg py-1 px-2 shadow-lg whitespace-nowrap">
                    <p className="font-bold">{day.date}</p>
                    <p className="text-emerald-300">Masuk: {formatCurrency(day.income, currency)}</p>
                    <p className="text-rose-300">Keluar: {formatCurrency(day.expense, currency)}</p>
                  </div>

                  <div className="w-full max-w-[32px] h-32 flex items-end justify-center gap-1">
                    {/* Income Bar */}
                    <div
                      style={{ height: `${Math.max(incPercent, 3)}%` }}
                      className={`w-1/2 bg-emerald-500 rounded-t-sm transition-all duration-300 group-hover:bg-emerald-600 ${
                        day.income === 0 ? 'opacity-20' : ''
                      }`}
                    />
                    {/* Expense Bar */}
                    <div
                      style={{ height: `${Math.max(expPercent, 3)}%` }}
                      className={`w-1/2 bg-rose-500 rounded-t-sm transition-all duration-300 group-hover:bg-rose-600 ${
                        day.expense === 0 ? 'opacity-20' : ''
                      }`}
                    />
                  </div>

                  <span className="text-[10px] font-semibold opacity-60 group-hover:opacity-100">
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
