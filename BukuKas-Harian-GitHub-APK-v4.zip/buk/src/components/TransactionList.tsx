import React, { useState, useMemo } from 'react';
import { CategoryItem, ColorMode, ThemeConfig, Transaction, TransactionType } from '../types';
import { formatCurrency, formatDateIndo, getPaymentMethodLabel } from '../utils/formatters';
import { CategoryIcon } from './CategoryIcon';
import {
  Search, Filter, Plus, Trash2, Edit2, ArrowDownRight,
  ArrowUpRight, Calendar, ArrowUpDown, ChevronDown
} from 'lucide-react';

interface TransactionListProps {
  transactions: Transaction[];
  categories: CategoryItem[];
  categoriesMap: Map<string, { icon: string; color: string }>;
  onEdit: (tx: Transaction) => void;
  onDelete: (id: string) => void;
  onAddNew: () => void;
  theme: ThemeConfig;
  colorMode: ColorMode;
  currency: string;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  categories,
  categoriesMap,
  onEdit,
  onDelete,
  onAddNew,
  theme,
  colorMode,
  currency,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | '7days' | 'this_month'>('this_month');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');

  const isDark = colorMode === 'dark';

  const filteredList = useMemo(() => {
    return transactions.filter(t => {
      // Type match
      if (typeFilter !== 'all' && t.type !== typeFilter) return false;

      // Category match
      if (categoryFilter !== 'all' && t.category !== categoryFilter) return false;

      // Date match
      const now = new Date();
      const txDate = new Date(t.date);

      if (dateFilter === 'today') {
        const todayStr = now.toISOString().slice(0, 10);
        if (t.date !== todayStr) return false;
      } else if (dateFilter === '7days') {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(now.getDate() - 7);
        if (txDate < sevenDaysAgo) return false;
      } else if (dateFilter === 'this_month') {
        if (
          txDate.getFullYear() !== now.getFullYear() ||
          txDate.getMonth() !== now.getMonth()
        ) {
          return false;
        }
      }

      // Search keyword match
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const inCat = t.category.toLowerCase().includes(q);
        const inNote = (t.note || '').toLowerCase().includes(q);
        const inMethod = t.paymentMethod.toLowerCase().includes(q);
        const inDate = t.date.includes(q);
        if (!inCat && !inNote && !inMethod && !inDate) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'date_desc') {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
      if (sortBy === 'date_asc') {
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      }
      if (sortBy === 'amount_desc') {
        return b.amount - a.amount;
      }
      if (sortBy === 'amount_asc') {
        return a.amount - b.amount;
      }
      return 0;
    });
  }, [transactions, typeFilter, categoryFilter, dateFilter, searchTerm, sortBy]);

  // Group by Date for cleaner financial journal look
  const groupedByDate = useMemo(() => {
    const groups: { date: string; displayDate: string; items: Transaction[] }[] = [];
    filteredList.forEach(t => {
      const existing = groups.find(g => g.date === t.date);
      if (existing) {
        existing.items.push(t);
      } else {
        groups.push({
          date: t.date,
          displayDate: formatDateIndo(t.date),
          items: [t],
        });
      }
    });
    return groups;
  }, [filteredList]);

  return (
    <div id="transactions-list-section" className="space-y-4">
      {/* Search & Filter Controls */}
      <div className={`rounded-2xl border p-4 shadow-xs space-y-3 transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200/80 text-slate-800'
      }`}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={16} className="absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              id="input-search-transactions"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Cari transaksi, kategori, atau catatan..."
              className={`w-full pl-10 pr-4 py-2 text-xs rounded-xl border outline-none ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-white focus:border-emerald-500'
                  : 'bg-white border-slate-200 text-slate-800 focus:border-emerald-500'
              }`}
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-add-tx-main"
              onClick={onAddNew}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-white font-bold text-xs shadow-xs transition-all ${theme.primary} ${theme.primaryHover}`}
            >
              <Plus size={15} />
              Catat Transaksi
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className={`flex flex-wrap items-center gap-2 pt-2 border-t text-xs ${
          isDark ? 'border-slate-800' : 'border-slate-100'
        }`}>
          {/* Type Filter */}
          <div className={`flex items-center p-1 rounded-xl ${isDark ? 'bg-slate-800' : 'bg-slate-100'}`}>
            <button
              type="button"
              onClick={() => setTypeFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                typeFilter === 'all'
                  ? isDark
                    ? 'bg-slate-700 text-white shadow-2xs'
                    : 'bg-white text-slate-900 shadow-2xs'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              Semua
            </button>
            <button
              type="button"
              onClick={() => setTypeFilter('expense')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                typeFilter === 'expense' ? 'bg-rose-600 text-white shadow-2xs' : 'opacity-70 hover:opacity-100'
              }`}
            >
              Pengeluaran
            </button>
            <button
              type="button"
              onClick={() => setTypeFilter('income')}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                typeFilter === 'income' ? 'bg-emerald-600 text-white shadow-2xs' : 'opacity-70 hover:opacity-100'
              }`}
            >
              Pemasukan
            </button>
          </div>

          {/* Date Filter */}
          <select
            value={dateFilter}
            onChange={e => setDateFilter(e.target.value as any)}
            className={`px-3 py-1.5 rounded-xl border font-medium outline-none ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <option value="this_month">Bulan Ini</option>
            <option value="7days">7 Hari Terakhir</option>
            <option value="today">Hari Ini</option>
            <option value="all">Semua Waktu</option>
          </select>

          {/* Category Dropdown */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className={`px-3 py-1.5 rounded-xl border font-medium outline-none max-w-[150px] truncate ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <option value="all">Semua Kategori</option>
            {categories.map(c => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Sort By */}
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className={`px-3 py-1.5 rounded-xl border font-medium outline-none ${
              isDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-200 text-slate-700'
            }`}
          >
            <option value="date_desc">Tanggal: Terbaru</option>
            <option value="date_asc">Tanggal: Terlama</option>
            <option value="amount_desc">Nominal: Terbesar</option>
            <option value="amount_asc">Nominal: Terkecil</option>
          </select>

          <span className="ml-auto text-[11px] opacity-60">
            Ditemukan: <strong>{filteredList.length}</strong> transaksi
          </span>
        </div>
      </div>

      {/* List Content */}
      {filteredList.length === 0 ? (
        <div className={`rounded-2xl border p-12 text-center shadow-xs ${
          isDark ? 'bg-slate-900 border-slate-800 text-slate-400' : 'bg-white border-slate-200 text-slate-500'
        }`}>
          <Calendar className="mx-auto mb-2 opacity-40" size={40} />
          <p className="text-sm font-bold">Tidak ada transaksi ditemukan</p>
          <p className="text-xs mt-1">Coba ubah filter pencarian atau catat transaksi baru.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {groupedByDate.map(group => {
            const dayExpense = group.items
              .filter(i => i.type === 'expense')
              .reduce((s, i) => s + i.amount, 0);
            const dayIncome = group.items
              .filter(i => i.type === 'income')
              .reduce((s, i) => s + i.amount, 0);

            return (
              <div key={group.date} className="space-y-2">
                {/* Date header with daily subtotal */}
                <div className="flex items-center justify-between px-2 pt-1 text-xs opacity-75 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Calendar size={13} className="opacity-60" />
                    {group.displayDate} ({group.date})
                  </span>
                  <div className="flex items-center gap-3 text-[11px]">
                    {dayIncome > 0 && (
                      <span className="text-emerald-600 font-bold">
                        +{formatCurrency(dayIncome, currency)}
                      </span>
                    )}
                    {dayExpense > 0 && (
                      <span className="text-rose-600 font-bold">
                        -{formatCurrency(dayExpense, currency)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Items */}
                <div className={`rounded-2xl border divide-y shadow-xs overflow-hidden ${
                  isDark
                    ? 'bg-slate-900 border-slate-800 divide-slate-800'
                    : 'bg-white border-slate-200/80 divide-slate-100'
                }`}>
                  {group.items.map(tx => {
                    const catInfo = categoriesMap.get(tx.category) || {
                      icon: 'CircleDollarSign',
                      color: '#94a3b8',
                    };
                    const methodBadge = getPaymentMethodLabel(tx.paymentMethod);

                    return (
                      <div
                        key={tx.id}
                        id={`tx-row-${tx.id}`}
                        className={`p-3.5 transition-colors flex items-center justify-between gap-3 group ${
                          isDark ? 'hover:bg-slate-800/60' : 'hover:bg-slate-50/80'
                        }`}
                      >
                        {/* Category Icon & Details */}
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                            style={{ backgroundColor: catInfo.color }}
                          >
                            <CategoryIcon name={catInfo.icon} size={18} />
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="text-xs font-bold truncate">
                                {tx.category}
                              </p>
                              <span
                                className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${
                                  isDark ? 'bg-slate-800 text-slate-300 border-slate-700' : `${methodBadge.bg} ${methodBadge.text}`
                                }`}
                              >
                                {methodBadge.label}
                              </span>
                            </div>
                            <p className="text-xs opacity-60 mt-0.5 truncate">
                              {tx.note ? tx.note : <span className="italic opacity-50">Tanpa catatan</span>}
                            </p>
                          </div>
                        </div>

                        {/* Amount & Actions */}
                        <div className="flex items-center gap-3 shrink-0">
                          <div className="text-right">
                            <p
                              className={`text-sm font-extrabold flex items-center justify-end gap-1 ${
                                tx.type === 'expense'
                                  ? isDark ? 'text-rose-400' : 'text-rose-600'
                                  : isDark ? 'text-emerald-400' : 'text-emerald-600'
                              }`}
                            >
                              {tx.type === 'expense' ? (
                                <ArrowDownRight size={15} />
                              ) : (
                                <ArrowUpRight size={15} />
                              )}
                              {formatCurrency(tx.amount, currency)}
                            </p>
                            <span className="text-[10px] opacity-50 font-medium">
                              {tx.time || '12:00'}
                            </span>
                          </div>

                          {/* Quick action buttons */}
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              type="button"
                              onClick={() => onEdit(tx)}
                              className={`p-1.5 rounded-lg transition-colors ${
                                isDark ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-400 hover:text-slate-800'
                              }`}
                              title="Edit Transaksi"
                            >
                              <Edit2 size={13} />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDelete(tx.id)}
                              className={`p-1.5 rounded-lg text-slate-400 transition-colors ${
                                isDark ? 'hover:bg-rose-950/70 hover:text-rose-400' : 'hover:bg-rose-50 hover:text-rose-600'
                              }`}
                              title="Hapus Transaksi"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
