import React, { useState } from 'react';
import {
  ShieldCheck,
  Users,
  Database,
  KeyRound,
  Trash2,
  Check,
  AlertCircle,
  Download,
  FileSpreadsheet,
  Lock,
  UserCheck,
  UserX,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { UserAccount, Transaction, SpreadsheetWebhookConfig } from '../types';
import { formatCurrency } from '../utils/formatters';
import { exportExpensesToCSV } from '../utils/storage';

interface AdminPanelProps {
  activeUser: UserAccount | null;
  users: UserAccount[];
  transactions: Transaction[];
  isDark: boolean;
  webhookConfig: SpreadsheetWebhookConfig;
  onUpdateUserRole: (userId: string, newRole: 'admin' | 'user') => void;
  onAdminResetUserPass: (userId: string, newPass: string) => void;
  onDeleteUser?: (userId: string) => void;
  onResetAllData: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  activeUser,
  users,
  transactions,
  isDark,
  webhookConfig,
  onUpdateUserRole,
  onAdminResetUserPass,
  onDeleteUser,
  onResetAllData,
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [searchUserQuery, setSearchUserQuery] = useState('');

  // Hitungan statistik global
  const totalUsers = users.length;
  const totalGlobalTx = transactions.length;
  const totalGlobalAmount = transactions.reduce((acc, t) => acc + t.amount, 0);

  // Map transaksi per user id
  const txCountByUser = new Map<string, number>();
  transactions.forEach(t => {
    const uid = t.userId || 'unassigned';
    txCountByUser.set(uid, (txCountByUser.get(uid) || 0) + 1);
  });

  const filteredUsers = users.filter(u => {
    const q = searchUserQuery.toLowerCase();
    return (
      u.name.toLowerCase().includes(q) ||
      u.username.toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q)
    );
  });

  const handleResetPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) return;
    if (newPasswordInput.length < 4) {
      setStatusMessage({ type: 'error', text: 'Kata sandi minimal 4 karakter.' });
      return;
    }

    onAdminResetUserPass(selectedUserId, newPasswordInput);
    setStatusMessage({ type: 'success', text: `Kata sandi untuk pengguna berhasil diatur ulang.` });
    setSelectedUserId(null);
    setNewPasswordInput('');
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const handleToggleRole = (user: UserAccount) => {
    if (user.id === activeUser?.id) {
      setStatusMessage({ type: 'error', text: 'Anda tidak dapat mengubah role akun admin Anda sendiri.' });
      setTimeout(() => setStatusMessage(null), 3000);
      return;
    }
    const nextRole = user.role === 'admin' ? 'user' : 'admin';
    onUpdateUserRole(user.id, nextRole);
    setStatusMessage({
      type: 'success',
      text: `Role ${user.name} berhasil diubah menjadi ${nextRole === 'admin' ? 'Admin' : 'Pengguna Biasa'}.`,
    });
    setTimeout(() => setStatusMessage(null), 3000);
  };

  return (
    <div id="admin-control-center" className="space-y-6 max-w-6xl mx-auto">
      {/* Admin Hero Header Banner */}
      <div className={`p-6 rounded-3xl border relative overflow-hidden transition-all ${
        isDark
          ? 'bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border-amber-900/40 text-white'
          : 'bg-gradient-to-br from-amber-500/10 via-amber-50 to-white border-amber-200 text-slate-900 shadow-sm'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center font-extrabold shadow-md shrink-0 mt-0.5">
              <ShieldCheck size={26} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold tracking-tight">
                  Panel Khusus Admin Utama
                </h2>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-500 text-slate-950">
                  Akses Penuh
                </span>
              </div>
              <p className="text-xs opacity-75 mt-1 max-w-xl">
                Halo <strong className="text-amber-500">{activeUser?.name || 'Hann'}</strong>, menu ini hanya terbuka khusus untuk Anda sebagai Admin. Anda dapat memantau seluruh pengguna terdaftar, mereset kata sandi, mengubah role, dan mengaudit data transaksi global.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-admin-export-all-csv"
              onClick={() => exportExpensesToCSV(transactions, users)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors shadow-2xs"
            >
              <Download size={15} />
              <span>Ekspor Database Master (CSV)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Global Status Banner & Feedback */}
      {statusMessage && (
        <div className={`p-3.5 rounded-2xl border text-xs flex items-center gap-2.5 transition-all ${
          statusMessage.type === 'success'
            ? isDark
              ? 'bg-emerald-950/50 border-emerald-900 text-emerald-300'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
            : isDark
            ? 'bg-rose-950/50 border-rose-900 text-rose-300'
            : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          {statusMessage.type === 'success' ? (
            <Check size={16} className="shrink-0 text-emerald-500" />
          ) : (
            <AlertCircle size={16} className="shrink-0 text-rose-500" />
          )}
          <span className="font-semibold">{statusMessage.text}</span>
        </div>
      )}

      {/* 4 Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-2xs'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Total Akun Terdaftar</span>
            <Users size={18} className="text-blue-500" />
          </div>
          <p className="text-2xl font-black">{totalUsers}</p>
          <p className="text-[11px] opacity-60 mt-1">Data akun tersimpan</p>
        </div>

        <div className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-2xs'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Total Transaksi Sistem</span>
            <Database size={18} className="text-emerald-500" />
          </div>
          <p className="text-2xl font-black">{totalGlobalTx}</p>
          <p className="text-[11px] opacity-60 mt-1">Seluruh transaksi pengguna</p>
        </div>

        <div className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-2xs'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Volume Finansial Global</span>
            <Sparkles size={18} className="text-amber-500" />
          </div>
          <p className="text-xl font-black truncate">{formatCurrency(totalGlobalAmount, 'IDR')}</p>
          <p className="text-[11px] opacity-60 mt-1">Perputaran dana tercatat</p>
        </div>

        <div className={`p-4 rounded-2xl border transition-colors ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-2xs'
        }`}>
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Status Webhook Admin</span>
            <FileSpreadsheet size={18} className="text-purple-500" />
          </div>
          <p className="text-sm font-bold flex items-center gap-1.5 mt-1">
            {webhookConfig.adminWebhookUrl ? (
              <span className="text-emerald-500 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                Tersambung (2-Sheet)
              </span>
            ) : (
              <span className="text-slate-400">Belum Terpasang</span>
            )}
          </p>
          <p className="text-[11px] opacity-60 mt-1">Google Apps Script Master</p>
        </div>
      </div>

      {/* User Management Table */}
      <div className={`rounded-3xl border overflow-hidden transition-colors ${
        isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-xs'
      }`}>
        <div className="p-5 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold tracking-tight">
              Daftar Seluruh Pengguna
            </h3>
            <p className="text-xs opacity-60">
              Kelola hak akses, periksa volume pencatatan, dan reset kata sandi pengguna secara langsung.
            </p>
          </div>

          <div className="relative">
            <input
              type="text"
              value={searchUserQuery}
              onChange={e => setSearchUserQuery(e.target.value)}
              placeholder="Cari user / username..."
              className={`px-3.5 py-1.5 rounded-xl border text-xs outline-none w-56 transition-colors ${
                isDark
                  ? 'bg-slate-800 border-slate-700 text-white placeholder:text-slate-500'
                  : 'bg-white border-slate-200 text-slate-900 placeholder:text-slate-400'
              }`}
            />
          </div>
        </div>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className={`font-bold border-b select-none ${
                isDark
                  ? 'bg-slate-800/80 text-slate-200 border-slate-700'
                  : 'bg-slate-100/90 text-slate-700 border-slate-200'
              }`}>
                <th className="py-3 px-4">Pengguna</th>
                <th className="py-3 px-3">Role Akses</th>
                <th className="py-3 px-3 text-center">Jumlah Transaksi</th>
                <th className="py-3 px-3">Mata Uang</th>
                <th className="py-3 px-4 text-right">Tindakan Admin</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isDark ? 'divide-slate-800' : 'divide-slate-100'}`}>
              {filteredUsers.map(user => {
                const isCurrent = user.id === activeUser?.id;
                const isAdmin = user.role === 'admin';
                const txCount = txCountByUser.get(user.id) || 0;

                return (
                  <tr
                    key={user.id}
                    className={`transition-colors ${
                      isDark ? 'hover:bg-slate-800/50' : 'hover:bg-slate-50'
                    }`}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-9 h-9 rounded-full object-cover border border-slate-300 dark:border-slate-700 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold truncate">{user.name}</span>
                            {isCurrent && (
                              <span className="text-[9px] bg-emerald-500/15 text-emerald-500 font-bold px-1.5 py-0.2 rounded">
                                Anda
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] opacity-60">@{user.username}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-3">
                      {isAdmin ? (
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                          isDark
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                            : 'bg-amber-50 text-amber-800 border-amber-200'
                        }`}>
                          <ShieldCheck size={11} /> Admin
                        </span>
                      ) : (
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${
                          isDark
                            ? 'bg-slate-800 text-slate-300 border-slate-700'
                            : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}>
                          Pengguna
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-3 text-center font-mono font-bold">
                      <span className={`px-2 py-0.5 rounded-lg ${
                        txCount > 0
                          ? isDark ? 'bg-emerald-950 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                          : 'opacity-40'
                      }`}>
                        {txCount} baris
                      </span>
                    </td>

                    <td className="py-3 px-3 font-mono font-semibold">
                      {user.currency || 'IDR'}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          id={`btn-admin-toggle-role-${user.id}`}
                          onClick={() => handleToggleRole(user)}
                          disabled={isCurrent}
                          title={isCurrent ? 'Tidak bisa mengubah role akun sendiri' : 'Ubah Role'}
                          className={`p-1.5 rounded-lg border text-xs transition-colors ${
                            isCurrent
                              ? 'opacity-30 cursor-not-allowed border-transparent'
                              : isDark
                              ? 'border-slate-700 hover:bg-slate-800 text-slate-300'
                              : 'border-slate-200 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          {isAdmin ? <UserX size={14} /> : <UserCheck size={14} />}
                        </button>

                        <button
                          type="button"
                          id={`btn-admin-reset-pass-${user.id}`}
                          onClick={() => {
                            setSelectedUserId(user.id);
                            setNewPasswordInput('');
                          }}
                          className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-[11px] font-bold transition-colors ${
                            isDark
                              ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                              : 'border-slate-200 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <KeyRound size={13} />
                          <span>Reset Sandi</span>
                        </button>

                        {onDeleteUser && !isCurrent && (
                          <button
                            type="button"
                            id={`btn-admin-delete-user-${user.id}`}
                            onClick={() => {
                              if (window.confirm(`Yakin ingin menghapus akun ${user.name}?`)) {
                                onDeleteUser(user.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition-colors"
                            title="Hapus Akun Pengguna"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Dialog: Reset Password User oleh Admin */}
      {selectedUserId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className={`w-full max-w-md rounded-3xl border p-6 shadow-2xl space-y-4 ${
            isDark ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-500 flex items-center justify-center">
                <Lock size={20} />
              </div>
              <div>
                <h4 className="text-base font-bold">Reset Kata Sandi Pengguna</h4>
                <p className="text-xs opacity-60">
                  Untuk akun: <span className="font-bold">{users.find(u => u.id === selectedUserId)?.name}</span>
                </p>
              </div>
            </div>

            <form onSubmit={handleResetPasswordSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold block mb-1">Kata Sandi / PIN Baru</label>
                <input
                  type="text"
                  value={newPasswordInput}
                  onChange={e => setNewPasswordInput(e.target.value)}
                  placeholder="Masukkan kata sandi baru (min. 4 karakter)"
                  required
                  autoFocus
                  className={`w-full px-3.5 py-2.5 rounded-xl border text-xs outline-none ${
                    isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedUserId(null)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border transition-colors ${
                    isDark ? 'border-slate-700 hover:bg-slate-800' : 'border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-2xs"
                >
                  Simpan Sandi Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Danger Zone / Reset All Data */}
      <div className={`rounded-3xl border p-6 ${
        isDark ? 'bg-rose-950/20 border-rose-900/50 text-rose-200' : 'bg-rose-50/70 border-rose-200 text-rose-950'
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-600 text-white flex items-center justify-center shrink-0 mt-0.5">
              <RotateCcw size={20} />
            </div>
            <div>
              <h4 className={`text-base font-bold ${isDark ? 'text-rose-400' : 'text-rose-700'}`}>
                Pembersihan Database & Reset Sistem
              </h4>
              <p className="text-xs opacity-80 mt-1 max-w-xl leading-relaxed">
                Tindakan darurat khusus admin untuk menghapus cache browser, mengosongkan seluruh data transaksi uji coba, dan mengembalikan akun admin Hann ke setelan standar.
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-admin-reset-system"
            onClick={() => {
              if (window.confirm('PERINGATAN ADMIN: Apakah Anda yakin ingin mereset seluruh data transaksi dan cache sistem?')) {
                onResetAllData();
              }
            }}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition-colors shrink-0 shadow-2xs"
          >
            <RotateCcw size={14} />
            <span>Reset Database Sistem</span>
          </button>
        </div>
      </div>
    </div>
  );
};
