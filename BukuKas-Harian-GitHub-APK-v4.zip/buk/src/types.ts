export type TransactionType = 'expense' | 'income';

export type PaymentMethod = 'cash' | 'transfer' | 'qris' | 'ewallet' | 'card';

export type UserRole = 'admin' | 'user';

export interface UserAccount {
  id: string;
  name: string;
  username: string;
  email: string;
  password?: string;
  role: UserRole;
  avatar: string;
  createdAt: string;
  monthlyBudget: number;
  currency: 'IDR' | 'USD' | 'MYR' | 'SGD' | 'EUR';
}

export interface CategoryItem {
  id: string;
  name: string;
  icon: string;
  color: string;
  type: TransactionType;
  isDefault?: boolean;
}

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  note: string;
  paymentMethod: PaymentMethod;
  createdAt: string;
}

export type ThemePreset = 'emerald' | 'ocean' | 'coral' | 'lavender' | 'midnight';

export type ColorMode = 'light' | 'dark';

export type NavPosition = 'top' | 'bottom';

export type PlusButtonPosition = 'bottom-center' | 'bottom-right' | 'topbar';

export interface ThemeConfig {
  id: ThemePreset;
  name: string;
  primary: string;
  primaryHover: string;
  primaryLight: string;
  primaryBorder: string;
  badgeBg: string;
  accent: string;
  gradient: string;
  surface: string;
  border: string;
  textPrimary: string;
}

export interface SpreadsheetWebhookConfig {
  enabled: boolean;
  webhookUrl: string; // Webhook URL untuk transaksi akun aktif
  adminWebhookUrl?: string; // Webhook URL Master Admin (mengelola 2 sheet: Semua Transaksi & Akun Pengguna)
  userWebhooks?: Record<string, string>; // Webhook transaksi per user ID
  lastSynced?: string;
  autoSync: boolean;
}
