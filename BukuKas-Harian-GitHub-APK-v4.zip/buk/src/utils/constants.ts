import { CategoryItem, ThemeConfig, ThemePreset, UserAccount, Transaction } from '../types';

export const DEFAULT_THEMES: Record<ThemePreset, ThemeConfig> = {
  emerald: {
    id: 'emerald',
    name: 'Emerald Mint (Default Finansial)',
    primary: 'bg-emerald-600',
    primaryHover: 'hover:bg-emerald-700',
    primaryLight: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    primaryBorder: 'border-emerald-500',
    badgeBg: 'bg-emerald-100 text-emerald-800',
    accent: '#059669',
    gradient: 'from-emerald-600 to-teal-700',
    surface: 'bg-white',
    border: 'border-slate-200',
    textPrimary: 'text-emerald-700',
  },
  ocean: {
    id: 'ocean',
    name: 'Ocean Blue (Profesional)',
    primary: 'bg-blue-600',
    primaryHover: 'hover:bg-blue-700',
    primaryLight: 'bg-blue-50 text-blue-700 border-blue-200',
    primaryBorder: 'border-blue-500',
    badgeBg: 'bg-blue-100 text-blue-800',
    accent: '#2563eb',
    gradient: 'from-blue-600 to-indigo-700',
    surface: 'bg-white',
    border: 'border-slate-200',
    textPrimary: 'text-blue-700',
  },
  coral: {
    id: 'coral',
    name: 'Sunset Coral (Hangat & Ceria)',
    primary: 'bg-rose-500',
    primaryHover: 'hover:bg-rose-600',
    primaryLight: 'bg-rose-50 text-rose-700 border-rose-200',
    primaryBorder: 'border-rose-500',
    badgeBg: 'bg-rose-100 text-rose-800',
    accent: '#f43f5e',
    gradient: 'from-rose-500 to-amber-600',
    surface: 'bg-white',
    border: 'border-slate-200',
    textPrimary: 'text-rose-600',
  },
  lavender: {
    id: 'lavender',
    name: 'Lavender Bloom (Estetik & Tenang)',
    primary: 'bg-purple-600',
    primaryHover: 'hover:bg-purple-700',
    primaryLight: 'bg-purple-50 text-purple-700 border-purple-200',
    primaryBorder: 'border-purple-500',
    badgeBg: 'bg-purple-100 text-purple-800',
    accent: '#9333ea',
    gradient: 'from-purple-600 to-pink-600',
    surface: 'bg-white',
    border: 'border-slate-200',
    textPrimary: 'text-purple-700',
  },
  midnight: {
    id: 'midnight',
    name: 'Midnight Slate (Mode Gelap Elegan)',
    primary: 'bg-slate-800',
    primaryHover: 'hover:bg-slate-900',
    primaryLight: 'bg-slate-100 text-slate-800 border-slate-300',
    primaryBorder: 'border-slate-700',
    badgeBg: 'bg-slate-200 text-slate-800',
    accent: '#1e293b',
    gradient: 'from-slate-800 to-slate-950',
    surface: 'bg-white',
    border: 'border-slate-200',
    textPrimary: 'text-slate-800',
  },
};

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  // Pengeluaran
  { id: 'cat-food', name: 'Makanan & Minuman', icon: 'Utensils', color: '#f97316', type: 'expense', isDefault: true },
  { id: 'cat-transport', name: 'Transportasi & Bensin', icon: 'Car', color: '#3b82f6', type: 'expense', isDefault: true },
  { id: 'cat-shopping', name: 'Belanja & Kebutuhan', icon: 'ShoppingBag', color: '#ec4899', type: 'expense', isDefault: true },
  { id: 'cat-bills', name: 'Tagihan & Utilitas', icon: 'Zap', color: '#eab308', type: 'expense', isDefault: true },
  { id: 'cat-entertainment', name: 'Hiburan & Liburan', icon: 'Film', color: '#8b5cf6', type: 'expense', isDefault: true },
  { id: 'cat-health', name: 'Kesehatan & Obat', icon: 'HeartPulse', color: '#ef4444', type: 'expense', isDefault: true },
  { id: 'cat-education', name: 'Pendidikan & Kursus', icon: 'GraduationCap', color: '#10b981', type: 'expense', isDefault: true },
  { id: 'cat-home', name: 'Rumah Tangga', icon: 'Home', color: '#64748b', type: 'expense', isDefault: true },
  { id: 'cat-other-exp', name: 'Lain-lain', icon: 'MoreHorizontal', color: '#94a3b8', type: 'expense', isDefault: true },

  // Pemasukan
  { id: 'cat-salary', name: 'Gaji Bulanan', icon: 'Briefcase', color: '#10b981', type: 'income', isDefault: true },
  { id: 'cat-business', name: 'Bisnis / Usaha', icon: 'Store', color: '#06b6d4', type: 'income', isDefault: true },
  { id: 'cat-freelance', name: 'Freelance / Sampingan', icon: 'Sparkles', color: '#8b5cf6', type: 'income', isDefault: true },
  { id: 'cat-invest', name: 'Investasi & Bunga', icon: 'TrendingUp', color: '#f59e0b', type: 'income', isDefault: true },
  { id: 'cat-gift', name: 'Hadiah / THR', icon: 'Gift', color: '#ec4899', type: 'income', isDefault: true },
];

export const AVAILABLE_ICONS = [
  'Utensils', 'Coffee', 'Car', 'Bus', 'ShoppingBag', 'ShoppingCart',
  'Zap', 'Wifi', 'Smartphone', 'Film', 'Music', 'Gamepad2',
  'HeartPulse', 'Dumbbell', 'GraduationCap', 'Book', 'Home', 'PiggyBank',
  'Briefcase', 'Store', 'Sparkles', 'TrendingUp', 'Gift', 'Wallet',
  'Coins', 'CreditCard', 'MoreHorizontal'
];

export const AVAILABLE_COLORS = [
  '#f97316', '#3b82f6', '#ec4899', '#eab308', '#8b5cf6',
  '#ef4444', '#10b981', '#06b6d4', '#64748b', '#f43f5e',
  '#84cc16', '#14b8a6', '#6366f1', '#d946ef', '#78716c'
];

export const ADMIN_USER: UserAccount = {
  id: 'usr-admin-hann',
  name: 'Hann',
  username: 'Hann',
  email: 'hannttm01@gmail.com',
  password: 'abogoboga',
  role: 'admin',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  createdAt: '2026-01-10',
  monthlyBudget: 5000000,
  currency: 'IDR',
};

export const DEMO_USER = ADMIN_USER;

export const DEMO_REGULAR_USER: UserAccount = {
  id: 'usr-user-02',
  name: 'Rian Anggota',
  username: 'rian',
  email: 'rian@example.com',
  password: '1234',
  role: 'user',
  avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
  createdAt: '2026-02-15',
  monthlyBudget: 2500000,
  currency: 'IDR',
};

// Data transaksi awal KOSONG untuk menjaga privasi akun baru dan pengguna
export const INITIAL_TRANSACTIONS: Transaction[] = [];

