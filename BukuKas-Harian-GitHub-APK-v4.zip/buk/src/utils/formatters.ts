import { PaymentMethod } from '../types';

export function formatCurrency(amount: number, currency = 'IDR'): string {
  if (isNaN(amount)) return 'Rp 0';
  
  if (currency === 'IDR') {
    return 'Rp ' + Math.round(amount).toLocaleString('id-ID');
  } else if (currency === 'USD') {
    return '$' + amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } else if (currency === 'MYR') {
    return 'RM ' + amount.toLocaleString('ms-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } else if (currency === 'SGD') {
    return 'S$' + amount.toLocaleString('en-SG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } else if (currency === 'EUR') {
    return '€' + amount.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  return amount.toLocaleString();
}

export function formatDateIndo(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  const date = new Date(Number(year), Number(month) - 1, Number(day));
  
  const today = new Date();
  const isToday = 
    today.getFullYear() === date.getFullYear() &&
    today.getMonth() === date.getMonth() &&
    today.getDate() === date.getDate();

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const isYesterday = 
    yesterday.getFullYear() === date.getFullYear() &&
    yesterday.getMonth() === date.getMonth() &&
    yesterday.getDate() === date.getDate();

  if (isToday) return 'Hari ini';
  if (isYesterday) return 'Kemarin';

  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
    'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'
  ];

  return `${Number(day)} ${months[Number(month) - 1]} ${year}`;
}

export function formatFullDate(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-');
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  return `${Number(day)} ${months[Number(month) - 1]} ${year}`;
}

export function getPaymentMethodLabel(method: PaymentMethod): { label: string; bg: string; text: string } {
  switch (method) {
    case 'qris':
      return { label: 'QRIS', bg: 'bg-rose-50 border-rose-200', text: 'text-rose-700' };
    case 'transfer':
      return { label: 'Transfer Bank', bg: 'bg-blue-50 border-blue-200', text: 'text-blue-700' };
    case 'ewallet':
      return { label: 'e-Wallet (GoPay/OVO/Dana)', bg: 'bg-emerald-50 border-emerald-200', text: 'text-emerald-700' };
    case 'card':
      return { label: 'Kartu Kredit / Debit', bg: 'bg-purple-50 border-purple-200', text: 'text-purple-700' };
    case 'cash':
    default:
      return { label: 'Tunai (Cash)', bg: 'bg-amber-50 border-amber-200', text: 'text-amber-800' };
  }
}
