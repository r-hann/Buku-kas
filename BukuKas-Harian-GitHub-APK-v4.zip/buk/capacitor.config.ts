import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.reyhan.bukukasharian',
  appName: 'BukuKas Harian',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
