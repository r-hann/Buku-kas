# BukuKas Harian

Aplikasi pencatatan pengeluaran harian berbasis React + Vite yang dapat dikemas menjadi APK Android menggunakan Capacitor.

## Build APK lewat GitHub Actions

1. Buat repository GitHub baru.
2. Upload seluruh isi project ini ke branch `main`.
3. Buka tab **Actions** di repository.
4. Pilih workflow **Build BukuKas APK**.
5. Klik **Run workflow** jika belum berjalan otomatis.
6. Setelah selesai, buka hasil workflow dan download artifact **BukuKas-Harian-APK**.
7. Di dalam artifact terdapat `app-debug.apk` yang dapat dipasang di Android.

## Build lokal

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Project ini tidak memerlukan Gemini API untuk menjalankan aplikasi.
