import { CategoryItem, ColorMode, NavPosition, PlusButtonPosition, SpreadsheetWebhookConfig, ThemePreset, Transaction, UserAccount } from '../types';
import { DEFAULT_CATEGORIES, DEFAULT_THEMES, DEMO_REGULAR_USER, DEMO_USER } from './constants';

const STORAGE_KEYS = {
  USERS: 'bukukas_users_v3',
  ACTIVE_USER: 'bukukas_active_user_v3',
  TRANSACTIONS: 'bukukas_transactions_v3',
  CATEGORIES: 'bukukas_categories_v3',
  THEME: 'bukukas_theme_v3',
  COLOR_MODE: 'bukukas_color_mode_v3',
  NAV_POSITION: 'bukukas_nav_pos_v3',
  PLUS_BTN_POSITION: 'bukukas_plus_pos_v3',
  WEBHOOK: 'bukukas_webhook_v3',
};

// Users - Default to admin user (without dummy regular clutter)
export function loadUsers(): UserAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USERS);
    if (!raw) {
      const initial = [DEMO_USER];
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(initial));
      return initial;
    }
    const parsed: UserAccount[] = JSON.parse(raw);
    const hasAdmin = parsed.some(u => u.role === 'admin' || u.email === 'hannttm01@gmail.com');
    if (!hasAdmin) {
      parsed.unshift(DEMO_USER);
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(parsed));
    }
    return parsed;
  } catch (e) {
    console.error('Failed to load users:', e);
    return [DEMO_USER];
  }
}

export function saveUsers(users: UserAccount[]): void {
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

// Active User
export function loadActiveUser(): UserAccount | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(DEMO_USER));
      return DEMO_USER;
    }
    const parsed: UserAccount = JSON.parse(raw);
    if (parsed.email === 'hannttm01@gmail.com') {
      parsed.role = 'admin';
    }
    return parsed;
  } catch (e) {
    return DEMO_USER;
  }
}

export function saveActiveUser(user: UserAccount | null): void {
  if (!user) {
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
  } else {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));
  }
}

// Transactions - Start with EMPTY list for fresh/clean user experience!
export function loadTransactions(): Transaction[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!raw) {
      // Empty by default for new installs/users!
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify([]));
      return [];
    }
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

export function saveTransactions(transactions: Transaction[]): void {
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
}

// Categories
export function loadCategories(): CategoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(DEFAULT_CATEGORIES));
      return DEFAULT_CATEGORIES;
    }
    return JSON.parse(raw);
  } catch (e) {
    return DEFAULT_CATEGORIES;
  }
}

export function saveCategories(categories: CategoryItem[]): void {
  localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
}

// Theme
export function loadTheme(): ThemePreset {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.THEME) as ThemePreset;
    if (raw && DEFAULT_THEMES[raw]) {
      return raw;
    }
    return 'emerald';
  } catch (e) {
    return 'emerald';
  }
}

export function saveTheme(theme: ThemePreset): void {
  localStorage.setItem(STORAGE_KEYS.THEME, theme);
}

// Color Mode (Light vs Dark)
export function loadColorMode(): ColorMode {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.COLOR_MODE) as ColorMode;
    return raw === 'dark' ? 'dark' : 'light';
  } catch (e) {
    return 'light';
  }
}

export function saveColorMode(mode: ColorMode): void {
  localStorage.setItem(STORAGE_KEYS.COLOR_MODE, mode);
}

// Navigation Bar Position (Top vs Bottom)
export function loadNavPosition(): NavPosition {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NAV_POSITION) as NavPosition;
    return raw === 'top' ? 'top' : 'bottom';
  } catch (e) {
    return 'bottom';
  }
}

export function saveNavPosition(pos: NavPosition): void {
  localStorage.setItem(STORAGE_KEYS.NAV_POSITION, pos);
}

// Plus Button Position
export function loadPlusButtonPosition(): PlusButtonPosition {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PLUS_BTN_POSITION) as PlusButtonPosition;
    return raw || 'bottom-center';
  } catch (e) {
    return 'bottom-center';
  }
}

export function savePlusButtonPosition(pos: PlusButtonPosition): void {
  localStorage.setItem(STORAGE_KEYS.PLUS_BTN_POSITION, pos);
}

// Webhook Config
export function loadWebhookConfig(): SpreadsheetWebhookConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WEBHOOK);
    if (raw) {
      return JSON.parse(raw);
    }
    return {
      enabled: false,
      webhookUrl: '',
      autoSync: true,
    };
  } catch (e) {
    return {
      enabled: false,
      webhookUrl: '',
      autoSync: true,
    };
  }
}

export function saveWebhookConfig(config: SpreadsheetWebhookConfig): void {
  localStorage.setItem(STORAGE_KEYS.WEBHOOK, JSON.stringify(config));
}

// CSV Export for Transactions
export function exportTransactionsToCSV(transactions: Transaction[], users?: UserAccount[]): void {
  const userMap = users ? new Map(users.map(u => [u.id, u.name])) : new Map();
  const headers = [
    'ID Transaksi',
    'Tanggal',
    'Waktu',
    'Tipe',
    'Kategori',
    'Nominal',
    'Metode Pembayaran',
    'Catatan',
    'Pengguna',
    'Dibuat Pada'
  ];

  const rows = transactions.map(t => [
    `"${t.id}"`,
    `"${t.date}"`,
    `"${t.time || ''}"`,
    `"${t.type === 'expense' ? 'Pengeluaran' : 'Pemasukan'}"`,
    `"${t.category.replace(/"/g, '""')}"`,
    t.amount,
    `"${t.paymentMethod}"`,
    `"${(t.note || '').replace(/"/g, '""')}"`,
    `"${(userMap.get(t.userId) || 'User').replace(/"/g, '""')}"`,
    `"${t.createdAt}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\r\n');
  const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `BukuKas_Spreadsheet_Transaksi_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Alias for backwards compatibility
export const exportExpensesToCSV = exportTransactionsToCSV;

// Parse CSV imported from Google Sheets / Excel
export function parseCSVToTransactions(csvText: string, currentUserId: string): Transaction[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length < 2) return [];

  const results: Transaction[] = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const cols = line.match(/(".*?"|[^",\s]+)(?=\s*,|\s*$)/g) || line.split(',');
    const clean = cols.map(c => c.replace(/^"|"$/g, '').trim());

    if (clean.length >= 5) {
      const date = clean[1] || new Date().toISOString().slice(0, 10);
      const time = clean[2] || '12:00';
      const typeRaw = (clean[3] || '').toLowerCase();
      const type = typeRaw.includes('masuk') || typeRaw === 'income' ? 'income' : 'expense';
      const category = clean[4] || 'Lain-lain';
      const amount = parseFloat(clean[5].replace(/[^0-9.-]+/g, '')) || 0;
      const paymentMethod = (clean[6] as any) || 'cash';
      const note = clean[7] || '';

      if (amount > 0) {
        results.push({
          id: `tx-imp-${Date.now()}-${i}`,
          userId: currentUserId,
          type,
          amount,
          category,
          date,
          time,
          note,
          paymentMethod: ['cash', 'transfer', 'qris', 'ewallet', 'card'].includes(paymentMethod) ? paymentMethod : 'cash',
          createdAt: new Date().toISOString(),
        });
      }
    }
  }
  return results;
}
