/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  CategoryItem,
  ColorMode,
  NavPosition,
  PlusButtonPosition,
  SpreadsheetWebhookConfig,
  ThemePreset,
  Transaction,
  TransactionType,
  UserAccount,
} from './types';
import { DEFAULT_CATEGORIES, DEFAULT_THEMES } from './utils/constants';
import {
  loadActiveUser,
  loadCategories,
  loadColorMode,
  loadNavPosition,
  loadPlusButtonPosition,
  loadTheme,
  loadTransactions,
  loadUsers,
  loadWebhookConfig,
  saveActiveUser,
  saveCategories,
  saveColorMode,
  saveNavPosition,
  savePlusButtonPosition,
  saveTheme,
  saveTransactions,
  saveUsers,
  saveWebhookConfig,
} from './utils/storage';
import { formatCurrency, formatDateIndo } from './utils/formatters';

// Components
import { Charts } from './components/Charts';
import { TransactionList } from './components/TransactionList';
import { SpreadsheetView } from './components/SpreadsheetView';
import { ThemeCustomizer } from './components/ThemeCustomizer';
import { AuthModal } from './components/AuthModal';
import { TransactionModal } from './components/TransactionModal';
import { CategoryModal } from './components/CategoryModal';
import { CategoryIcon } from './components/CategoryIcon';

// Lucide Icons
import {
  Wallet,
  ArrowDownRight,
  ArrowUpRight,
  Plus,
  BarChart3,
  ListOrdered,
  Layers,
  FileSpreadsheet,
  Settings,
  User,
  LogOut,
  Sparkles,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  ChevronRight,
  Sun,
  Moon,
  ShieldCheck,
  KeyRound,
} from 'lucide-react';

export default function App() {
  // Core persistent states
  const [users, setUsers] = useState<UserAccount[]>(loadUsers);
  const [activeUser, setActiveUser] = useState<UserAccount | null>(loadActiveUser);
  const [transactions, setTransactions] = useState<Transaction[]>(loadTransactions);
  const [categories, setCategories] = useState<CategoryItem[]>(loadCategories);
  const [themeKey, setThemeKey] = useState<ThemePreset>(loadTheme);
  const [colorMode, setColorMode] = useState<ColorMode>(loadColorMode);
  const [navPosition, setNavPosition] = useState<NavPosition>(loadNavPosition);
  const [plusButtonPosition, setPlusButtonPosition] = useState<PlusButtonPosition>(loadPlusButtonPosition);
  const [webhookConfig, setWebhookConfig] = useState<SpreadsheetWebhookConfig>(loadWebhookConfig);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'spreadsheet' | 'settings'>('dashboard');

  // Modal controls
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isTxModalOpen, setIsTxModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);

  // Sync to local storage
  useEffect(() => {
    saveUsers(users);
  }, [users]);

  useEffect(() => {
    saveActiveUser(activeUser);
  }, [activeUser]);

  useEffect(() => {
    saveTransactions(transactions);
  }, [transactions]);

  useEffect(() => {
    saveCategories(categories);
  }, [categories]);

  useEffect(() => {
    saveTheme(themeKey);
  }, [themeKey]);

  useEffect(() => {
    saveColorMode(colorMode);
    if (colorMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [colorMode]);

  useEffect(() => {
    saveNavPosition(navPosition);
  }, [navPosition]);

  useEffect(() => {
    savePlusButtonPosition(plusButtonPosition);
  }, [plusButtonPosition]);

  useEffect(() => {
    saveWebhookConfig(webhookConfig);
  }, [webhookConfig]);

  const currentTheme = DEFAULT_THEMES[themeKey] || DEFAULT_THEMES.emerald;
  const currency = activeUser?.currency || 'IDR';
  const isDark = colorMode === 'dark';
  const isAdmin = activeUser?.role === 'admin' || activeUser?.email === 'hannttm01@gmail.com';

  // User-scoped transactions (Setiap akun baru memiliki data transaksi terpisah dan mulai dari kosong)
  const userTransactions = useMemo(() => {
    if (!activeUser) return [];
    // If admin, show all or filtered by user; by default show activeUser's transactions
    return transactions.filter(t => !t.userId || t.userId === activeUser.id);
  }, [transactions, activeUser]);

  // Category map for fast lookups
  const categoriesMap = useMemo(() => {
    const map = new Map<string, { icon: string; color: string }>();
    categories.forEach(c => {
      map.set(c.name, { icon: c.icon, color: c.color });
    });
    return map;
  }, [categories]);

  // Current Month calculations based on active user transactions
  const now = new Date();
  const currentMonthTx = useMemo(() => {
    return userTransactions.filter(t => {
      const d = new Date(t.date);
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    });
  }, [userTransactions]);

  const totalIncomeAll = useMemo(
    () => userTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0),
    [userTransactions]
  );
  const totalExpenseAll = useMemo(
    () => userTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0),
    [userTransactions]
  );
  const netBalance = totalIncomeAll - totalExpenseAll;

  const totalExpenseThisMonth = useMemo(
    () => currentMonthTx.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0),
    [currentMonthTx]
  );
  const totalIncomeThisMonth = useMemo(
    () => currentMonthTx.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0),
    [currentMonthTx]
  );

  const monthlyBudget = activeUser?.monthlyBudget || 4000000;
  const budgetUsagePercent = monthlyBudget > 0 ? (totalExpenseThisMonth / monthlyBudget) * 100 : 0;

  // Handlers
  const handleSaveTransaction = (
    txData: Omit<Transaction, 'id' | 'createdAt'>,
    editId?: string
  ) => {
    if (editId) {
      setTransactions(prev =>
        prev.map(t =>
          t.id === editId
            ? { ...t, ...txData }
            : t
        )
      );
    } else {
      const newTx: Transaction = {
        ...txData,
        id: `tx-${Date.now()}`,
        createdAt: new Date().toISOString(),
      };
      setTransactions(prev => [newTx, ...prev]);

      // If Google Sheets webhook is configured, dispatch asynchronously
      if (webhookConfig.enabled) {
        // 1. Kirim ke Webhook Pribadi Pengguna (jika dikonfigurasi) - Hanya 1 Sheet Transaksi
        const userWebhookUrl =
          (activeUser?.id && webhookConfig.userWebhooks?.[activeUser.id]) ||
          (activeUser?.role !== 'admin' ? webhookConfig.webhookUrl : '');

        if (userWebhookUrl) {
          try {
            fetch(userWebhookUrl, {
              method: 'POST',
              mode: 'no-cors',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                ...newTx,
                action: 'save_transaction',
              }),
            }).catch(err => console.log('User webhook sync:', err));
          } catch (e) {
            // silent in dev
          }
        }

        // 2. Kirim ke Master Webhook Admin (jika dikonfigurasi) - Sheet Semua_Transaksi
        if (webhookConfig.adminWebhookUrl && webhookConfig.adminWebhookUrl !== userWebhookUrl) {
          try {
            fetch(webhookConfig.adminWebhookUrl, {
              method: 'POST',
              mode: 'no-cors',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                ...newTx,
                userName: activeUser?.name || 'User',
                action: 'save_transaction',
              }),
            }).catch(err => console.log('Admin master webhook sync:', err));
          } catch (e) {
            // silent in dev
          }
        }
      }
    }
  };

  const handleDeleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  const handleEditTransaction = (tx: Transaction) => {
    setEditingTx(tx);
    setIsTxModalOpen(true);
  };

  const handleSaveCategory = (cat: CategoryItem) => {
    setCategories(prev => [...prev, cat]);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  const handleClearCategories = (type: TransactionType) => {
    setCategories(prev => prev.filter(c => c.type !== type));
  };

  const handleResetDefaultCategories = () => {
    setCategories(DEFAULT_CATEGORIES);
  };

  const handleImportTransactions = (imported: Transaction[]) => {
    setTransactions(prev => [...imported, ...prev]);
  };

  const handleUpdateActiveUser = (updated: Partial<UserAccount>) => {
    if (!activeUser) return;
    const next = { ...activeUser, ...updated };
    setActiveUser(next);
    setUsers(prev => prev.map(u => (u.id === next.id ? next : u)));
  };

  const handleUpdateUserRole = (userId: string, newRole: 'admin' | 'user') => {
    setUsers(prev =>
      prev.map(u => (u.id === userId ? { ...u, role: newRole } : u))
    );
    if (activeUser && activeUser.id === userId) {
      setActiveUser(prev => (prev ? { ...prev, role: newRole } : null));
    }
  };

  const handleAdminResetUserPass = (userId: string, newPass: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === userId ? { ...u, password: newPass } : u))
    );
    if (activeUser && activeUser.id === userId) {
      setActiveUser(prev => (prev ? { ...prev, password: newPass } : null));
    }
  };

  const handleResetPassword = (userId: string, newPass: string) => {
    setUsers(prev =>
      prev.map(u => (u.id === userId ? { ...u, password: newPass } : u))
    );
    if (activeUser && activeUser.id === userId) {
      setActiveUser(prev => (prev ? { ...prev, password: newPass } : null));
    }
  };

  const handleResetData = () => {
    localStorage.clear();
    window.location.reload();
  };

  const toggleColorMode = () => {
    setColorMode(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  const navItems = [
    { id: 'dashboard' as const, label: 'Ringkasan', icon: BarChart3 },
    { id: 'transactions' as const, label: `Catatan (${transactions.length})`, icon: ListOrdered },
    { id: 'spreadsheet' as const, label: 'Sheet DB', icon: FileSpreadsheet, isSpreadsheet: true },
    { id: 'settings' as const, label: 'Kustomisasi', icon: Settings },
  ];

  return (
    <div className={`min-h-screen flex flex-col font-sans selection:bg-emerald-500 selection:text-white transition-colors duration-200 ${
      isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50/70 text-slate-800'
    } ${navPosition === 'bottom' ? 'pb-28' : 'pb-16'}`}>
      {/* Top Navbar */}
      <header className={`sticky top-0 z-40 backdrop-blur-md border-b transition-colors ${
        isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white/95 border-slate-200 shadow-2xs'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${currentTheme.gradient} text-white flex items-center justify-center shadow-xs`}
            >
              <Wallet size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-extrabold tracking-tight">
                  BukuKas
                </span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                  isDark ? 'bg-slate-800 text-slate-300 border-slate-700' : 'bg-slate-100 text-slate-600 border-slate-200'
                }`}>
                  Harian
                </span>
              </div>
              <p className="text-[10px] opacity-60 hidden sm:block">
                Spreadsheet & Keuangan Ringan
              </p>
            </div>
          </div>

          {/* Top Navigation Bar (Active when navPosition === 'top') */}
          {navPosition === 'top' && (
            <nav className={`hidden md:flex items-center gap-1 p-1 rounded-2xl border ${
              isDark ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-100/90 border-slate-200/60'
            }`}>
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    id={`nav-tab-${item.id}`}
                    onClick={() => setActiveTab(item.id)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                      isActive
                        ? isDark
                          ? 'bg-slate-700 text-white shadow-xs'
                          : 'bg-white text-slate-900 shadow-xs'
                        : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    <Icon size={14} className={item.isSpreadsheet ? 'text-emerald-500' : ''} />
                    {item.label}
                  </button>
                );
              })}

              <button
                type="button"
                id="nav-tab-categories"
                onClick={() => setIsCatModalOpen(true)}
                className="px-3.5 py-1.5 rounded-xl text-xs font-bold opacity-70 hover:opacity-100 transition-all flex items-center gap-1.5"
              >
                <Layers size={14} />
                Kategori
              </button>
            </nav>
          )}

          {/* Right Controls: Quick Add, Dark/Light Toggle & User Profile */}
          <div className="flex items-center gap-2">
            {/* Quick Dark/Light Mode Toggle */}
            <button
              type="button"
              id="btn-header-theme-toggle"
              onClick={toggleColorMode}
              className={`p-2 rounded-xl border transition-colors ${
                isDark
                  ? 'border-slate-800 bg-slate-800/80 text-amber-400 hover:bg-slate-750'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
              title={isDark ? 'Beralih ke Mode Terang' : 'Beralih ke Mode Gelap'}
            >
              {isDark ? <Sun size={17} /> : <Moon size={17} />}
            </button>

            {/* Quick Record Button (If topbar position or desktop topnav) */}
            {(plusButtonPosition === 'topbar' || (plusButtonPosition === 'bottom-center' && navPosition === 'top')) && (
              <button
                type="button"
                id="btn-quick-record-topbar"
                onClick={() => {
                  setEditingTx(null);
                  setIsTxModalOpen(true);
                }}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-white font-bold text-xs shadow-xs transition-all ${currentTheme.primary} ${currentTheme.primaryHover}`}
              >
                <Plus size={16} />
                <span className="hidden sm:inline">Catat Transaksi</span>
              </button>
            )}

            {/* Profile Pill & Switcher */}
            <button
              type="button"
              id="btn-user-profile-header"
              onClick={() => setIsAuthModalOpen(true)}
              className={`flex items-center gap-2 p-1.5 pr-3 rounded-2xl border transition-all shadow-2xs ${
                isDark
                  ? 'border-slate-800 bg-slate-900 hover:bg-slate-800 text-white'
                  : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-800'
              }`}
            >
              <img
                src={
                  activeUser?.avatar ||
                  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
                }
                alt={activeUser?.name || 'User'}
                className={`w-7 h-7 rounded-full object-cover border ${
                  isDark ? 'border-slate-700' : 'border-slate-200'
                }`}
              />
              <div className="text-left hidden sm:block">
                <div className="flex items-center gap-1.5">
                  <p className="text-xs font-bold leading-tight truncate max-w-[90px]">
                    {activeUser?.name || 'Akun'}
                  </p>
                  {isAdmin ? (
                    <span className={`text-[9px] font-extrabold px-1 py-0.2 rounded border flex items-center gap-0.5 ${
                      isDark ? 'bg-amber-500/20 text-amber-400 border-amber-500/30' : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                      <ShieldCheck size={9} /> Admin
                    </span>
                  ) : (
                    <span className={`text-[9px] font-semibold px-1 py-0.2 rounded ${
                      isDark ? 'bg-slate-700 text-slate-300' : 'bg-slate-200 text-slate-700'
                    }`}>
                      User
                    </span>
                  )}
                </div>
                <p className="text-[10px] opacity-60 leading-tight">
                  @{activeUser?.username || 'user'}
                </p>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Top Navigation (Only shown when navPosition === 'top') */}
        {navPosition === 'top' && (
          <div className={`md:hidden flex items-center justify-around border-t py-1.5 px-2 ${
            isDark ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-slate-50'
          }`}>
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-bold transition-colors ${
                    isActive
                      ? isDark
                        ? 'text-emerald-400 font-extrabold'
                        : 'text-emerald-700 font-extrabold'
                      : 'opacity-60'
                  }`}
                >
                  <Icon size={16} />
                  {item.label.split(' ')[0]}
                </button>
              );
            })}
            <button
              type="button"
              onClick={() => setIsCatModalOpen(true)}
              className="flex flex-col items-center py-1 px-2 rounded-lg text-[10px] font-bold opacity-60"
            >
              <Layers size={16} />
              Kategori
            </button>
          </div>
        )}
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 flex-1 w-full space-y-6">
        {/* TAB 1: DASHBOARD & CHARTS */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Top Financial Stat Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Card 1: Saldo Bersih */}
              <div className={`rounded-2xl border p-4.5 shadow-xs flex flex-col justify-between transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200/80'
              }`}>
                <div>
                  <div className="flex items-center justify-between opacity-70 mb-1">
                    <span className="text-xs font-semibold">Total Saldo Bersih</span>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      isDark ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-700'
                    }`}>
                      <Wallet size={16} />
                    </div>
                  </div>
                  <h3
                    className={`text-xl font-extrabold tracking-tight ${
                      netBalance >= 0
                        ? isDark
                          ? 'text-white'
                          : 'text-slate-900'
                        : isDark
                        ? 'text-rose-400'
                        : 'text-rose-600'
                    }`}
                  >
                    {formatCurrency(netBalance, currency)}
                  </h3>
                </div>
                <div className={`pt-3 mt-2 border-t flex items-center justify-between text-[11px] opacity-70 ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}>
                  <span>Akumulasi semua transaksi</span>
                  <span className="font-semibold text-emerald-500">Aktif</span>
                </div>
              </div>

              {/* Card 2: Pengeluaran Bulan Ini */}
              <div className={`rounded-2xl border p-4.5 shadow-xs flex flex-col justify-between transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200/80'
              }`}>
                <div>
                  <div className="flex items-center justify-between opacity-70 mb-1">
                    <span className="text-xs font-semibold">Pengeluaran Bulan Ini</span>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      isDark ? 'bg-rose-950/60 text-rose-400' : 'bg-rose-50 text-rose-600'
                    }`}>
                      <ArrowDownRight size={16} />
                    </div>
                  </div>
                  <h3 className={`text-xl font-extrabold tracking-tight ${
                    isDark ? 'text-rose-400' : 'text-rose-600'
                  }`}>
                    -{formatCurrency(totalExpenseThisMonth, currency)}
                  </h3>
                </div>
                <div className={`pt-3 mt-2 border-t flex items-center justify-between text-[11px] opacity-70 ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}>
                  <span>Bulan {now.toLocaleString('id-ID', { month: 'long' })}</span>
                  <span className="font-semibold">
                    {currentMonthTx.filter(t => t.type === 'expense').length} kali
                  </span>
                </div>
              </div>

              {/* Card 3: Pemasukan Bulan Ini */}
              <div className={`rounded-2xl border p-4.5 shadow-xs flex flex-col justify-between transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200/80'
              }`}>
                <div>
                  <div className="flex items-center justify-between opacity-70 mb-1">
                    <span className="text-xs font-semibold">Pemasukan Bulan Ini</span>
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                      isDark ? 'bg-emerald-950/60 text-emerald-400' : 'bg-emerald-50 text-emerald-600'
                    }`}>
                      <ArrowUpRight size={16} />
                    </div>
                  </div>
                  <h3 className={`text-xl font-extrabold tracking-tight ${
                    isDark ? 'text-emerald-400' : 'text-emerald-600'
                  }`}>
                    +{formatCurrency(totalIncomeThisMonth, currency)}
                  </h3>
                </div>
                <div className={`pt-3 mt-2 border-t flex items-center justify-between text-[11px] opacity-70 ${
                  isDark ? 'border-slate-800' : 'border-slate-100'
                }`}>
                  <span>Bulan {now.toLocaleString('id-ID', { month: 'long' })}</span>
                  <span className="font-semibold">
                    {currentMonthTx.filter(t => t.type === 'income').length} kali
                  </span>
                </div>
              </div>

              {/* Card 4: Budget Tracker Progress */}
              <div className={`rounded-2xl border p-4.5 shadow-xs flex flex-col justify-between transition-colors ${
                isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200/80'
              }`}>
                <div>
                  <div className="flex items-center justify-between opacity-70 mb-1">
                    <span className="text-xs font-semibold">Batas Anggaran (Budget)</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        budgetUsagePercent > 100
                          ? isDark ? 'bg-rose-950 text-rose-300' : 'bg-rose-100 text-rose-700'
                          : budgetUsagePercent > 80
                          ? isDark ? 'bg-amber-950 text-amber-300' : 'bg-amber-100 text-amber-700'
                          : isDark ? 'bg-emerald-950 text-emerald-300' : 'bg-emerald-100 text-emerald-700'
                      }`}
                    >
                      {budgetUsagePercent.toFixed(0)}% Terpakai
                    </span>
                  </div>
                  <div className="flex items-baseline justify-between mt-1">
                    <h3 className="text-sm font-bold">
                      {formatCurrency(totalExpenseThisMonth, currency)}
                    </h3>
                    <span className="text-xs opacity-60">
                      / {formatCurrency(monthlyBudget, currency)}
                    </span>
                  </div>
                </div>

                <div className="pt-2 mt-2">
                  <div className={`w-full h-2 rounded-full overflow-hidden ${
                    isDark ? 'bg-slate-800' : 'bg-slate-100'
                  }`}>
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        budgetUsagePercent > 100
                          ? 'bg-rose-500'
                          : budgetUsagePercent > 80
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(budgetUsagePercent, 100)}%` }}
                    />
                  </div>
                  <p className="text-[10px] opacity-60 mt-1.5 flex items-center justify-between">
                    <span>
                      Sisa budget:{' '}
                      <strong className={isDark ? 'text-white' : 'text-slate-700'}>
                        {formatCurrency(Math.max(0, monthlyBudget - totalExpenseThisMonth), currency)}
                      </strong>
                    </span>
                    {budgetUsagePercent > 100 && (
                      <span className={`font-bold flex items-center gap-0.5 ${
                        isDark ? 'text-rose-400' : 'text-rose-600'
                      }`}>
                        <AlertTriangle size={11} /> Overbudget
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <Charts
              transactions={userTransactions}
              categoriesMap={categoriesMap}
              theme={currentTheme}
              colorMode={colorMode}
              currency={currency}
            />

            {/* Recent Transactions Snippet & Quick Actions */}
            <div className={`rounded-2xl border p-5 shadow-xs transition-colors ${
              isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200/80'
            }`}>
              <div className={`flex items-center justify-between mb-4 pb-3 border-b ${
                isDark ? 'border-slate-800' : 'border-slate-100'
              }`}>
                <div>
                  <h3 className="text-sm font-bold flex items-center gap-2">
                    <Calendar size={16} className="opacity-60" />
                    Transaksi Terbaru
                  </h3>
                  <p className="text-xs opacity-60 mt-0.5">
                    Catatan pengeluaran & pemasukan terakhir
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('transactions')}
                  className="text-xs font-bold text-emerald-500 hover:text-emerald-400 flex items-center gap-1"
                >
                  Lihat Semua ({userTransactions.length}) <ChevronRight size={14} />
                </button>
              </div>

              {userTransactions.length === 0 ? (
                <div className="py-8 text-center text-xs opacity-50">
                  Belum ada transaksi. Klik tombol (+) untuk mencatat pengeluaran pertama Anda.
                </div>
              ) : (
                <div className={`divide-y ${isDark ? 'divide-slate-800' : 'divide-slate-100'}`}>
                  {userTransactions.slice(0, 5).map(tx => {
                    const catInfo = categoriesMap.get(tx.category) || {
                      icon: 'CircleDollarSign',
                      color: '#94a3b8',
                    };
                    return (
                      <div
                        key={tx.id}
                        className={`py-3 flex items-center justify-between gap-3 px-2 rounded-xl transition-colors ${
                          isDark ? 'hover:bg-slate-800/60' : 'hover:bg-slate-50/60'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-9 h-9 rounded-xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                            style={{ backgroundColor: catInfo.color }}
                          >
                            <CategoryIcon name={catInfo.icon} size={16} />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold truncate">{tx.category}</p>
                            <p className="text-[11px] opacity-60 truncate">
                              {tx.note || formatDateIndo(tx.date)}
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <p
                            className={`text-xs font-extrabold ${
                              tx.type === 'expense'
                                ? isDark ? 'text-rose-400' : 'text-rose-600'
                                : isDark ? 'text-emerald-400' : 'text-emerald-600'
                            }`}
                          >
                            {tx.type === 'expense' ? '-' : '+'}
                            {formatCurrency(tx.amount, currency)}
                          </p>
                          <p className="text-[10px] opacity-50">{formatDateIndo(tx.date)}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: TRANSACTIONS LIST */}
        {activeTab === 'transactions' && (
          <TransactionList
            transactions={userTransactions}
            categories={categories}
            categoriesMap={categoriesMap}
            onEdit={handleEditTransaction}
            onDelete={handleDeleteTransaction}
            onAddNew={() => {
              setEditingTx(null);
              setIsTxModalOpen(true);
            }}
            theme={currentTheme}
            colorMode={colorMode}
            currency={currency}
          />
        )}

        {/* TAB 3: SPREADSHEET DATABASE VIEW */}
        {activeTab === 'spreadsheet' && (
          <SpreadsheetView
            transactions={transactions}
            users={users}
            activeUser={activeUser}
            onImportTransactions={handleImportTransactions}
            webhookConfig={webhookConfig}
            onSaveWebhookConfig={setWebhookConfig}
            theme={currentTheme}
            colorMode={colorMode}
            currency={currency}
          />
        )}

        {/* TAB 4: SETTINGS & THEME CUSTOMIZER */}
        {activeTab === 'settings' && (
          <ThemeCustomizer
            currentTheme={themeKey}
            onSelectTheme={setThemeKey}
            colorMode={colorMode}
            onToggleColorMode={setColorMode}
            navPosition={navPosition}
            onSelectNavPosition={setNavPosition}
            plusButtonPosition={plusButtonPosition}
            onSelectPlusButtonPosition={setPlusButtonPosition}
            activeUser={activeUser}
            users={users}
            onUpdateUser={handleUpdateActiveUser}
            onResetData={handleResetData}
            onOpenResetPasswordModal={() => setIsAuthModalOpen(true)}
          />
        )}
      </main>

      {/* FLOATING BOTTOM DOCK NAVIGATION (Active when navPosition === 'bottom') */}
      {navPosition === 'bottom' && (
        <nav
          id="floating-bottom-dock"
          className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-[94%] max-w-lg animate-fadeIn"
        >
          <div
            className={`px-3 py-2 rounded-3xl border shadow-xl backdrop-blur-md flex items-center justify-between gap-1 transition-colors ${
              isDark
                ? 'bg-slate-900/95 border-slate-800 text-slate-300'
                : 'bg-white/95 border-slate-200 text-slate-600 shadow-slate-200/50'
            }`}
          >
            {/* Tab 1: Ringkasan */}
            <button
              type="button"
              id="dock-tab-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`flex-1 flex flex-col items-center py-1.5 px-1 rounded-2xl text-[10px] font-bold transition-all ${
                activeTab === 'dashboard'
                  ? isDark
                    ? 'text-emerald-400 bg-slate-800/80 scale-105'
                    : 'text-emerald-700 bg-slate-100 scale-105'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <BarChart3 size={18} />
              <span className="mt-0.5 truncate">Grafik</span>
            </button>

            {/* Tab 2: Catatan */}
            <button
              type="button"
              id="dock-tab-transactions"
              onClick={() => setActiveTab('transactions')}
              className={`flex-1 flex flex-col items-center py-1.5 px-1 rounded-2xl text-[10px] font-bold transition-all ${
                activeTab === 'transactions'
                  ? isDark
                    ? 'text-emerald-400 bg-slate-800/80 scale-105'
                    : 'text-emerald-700 bg-slate-100 scale-105'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <ListOrdered size={18} />
              <span className="mt-0.5 truncate">Catatan</span>
            </button>

            {/* Center Plus Button (if plusButtonPosition === 'bottom-center') */}
            {plusButtonPosition === 'bottom-center' && (
              <div className="flex-1 flex justify-center -my-3">
                <button
                  type="button"
                  id="dock-btn-add-center"
                  onClick={() => {
                    setEditingTx(null);
                    setIsTxModalOpen(true);
                  }}
                  className={`w-12 h-12 rounded-full text-white flex items-center justify-center shadow-lg transition-transform hover:scale-110 active:scale-95 ${currentTheme.primary} ${currentTheme.primaryHover}`}
                  title="Catat Transaksi"
                >
                  <Plus size={24} strokeWidth={2.5} />
                </button>
              </div>
            )}

            {/* Tab 3: Spreadsheet */}
            <button
              type="button"
              id="dock-tab-spreadsheet"
              onClick={() => setActiveTab('spreadsheet')}
              className={`flex-1 flex flex-col items-center py-1.5 px-1 rounded-2xl text-[10px] font-bold transition-all ${
                activeTab === 'spreadsheet'
                  ? isDark
                    ? 'text-emerald-400 bg-slate-800/80 scale-105'
                    : 'text-emerald-700 bg-slate-100 scale-105'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <FileSpreadsheet size={18} className="text-emerald-500" />
              <span className="mt-0.5 truncate">Sheet DB</span>
            </button>

            {/* Tab 4: Kategori modal trigger */}
            <button
              type="button"
              id="dock-tab-categories"
              onClick={() => setIsCatModalOpen(true)}
              className="flex-1 flex flex-col items-center py-1.5 px-1 rounded-2xl text-[10px] font-bold opacity-70 hover:opacity-100 transition-all"
            >
              <Layers size={18} />
              <span className="mt-0.5 truncate">Kategori</span>
            </button>

            {/* Tab 5: Kustomisasi */}
            <button
              type="button"
              id="dock-tab-settings"
              onClick={() => setActiveTab('settings')}
              className={`flex-1 flex flex-col items-center py-1.5 px-1 rounded-2xl text-[10px] font-bold transition-all ${
                activeTab === 'settings'
                  ? isDark
                    ? 'text-emerald-400 bg-slate-800/80 scale-105'
                    : 'text-emerald-700 bg-slate-100 scale-105'
                  : 'opacity-70 hover:opacity-100'
              }`}
            >
              <Settings size={18} />
              <span className="mt-0.5 truncate">Tema</span>
            </button>
          </div>
        </nav>
      )}

      {/* FLOATING ACTION BUTTON (If plusButtonPosition === 'bottom-right') */}
      {plusButtonPosition === 'bottom-right' && (
        <button
          type="button"
          id="btn-fab-add-bottom-right"
          onClick={() => {
            setEditingTx(null);
            setIsTxModalOpen(true);
          }}
          className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full text-white flex items-center justify-center shadow-xl transition-transform hover:scale-110 active:scale-95 ${currentTheme.primary} ${currentTheme.primaryHover}`}
          title="Catat Transaksi"
        >
          <Plus size={28} strokeWidth={2.5} />
        </button>
      )}

      {/* FLOATING ACTION BUTTON (If plusButtonPosition === 'bottom-center' AND navPosition === 'top') */}
      {plusButtonPosition === 'bottom-center' && navPosition === 'top' && (
        <button
          type="button"
          id="btn-fab-add-bottom-center-standalone"
          onClick={() => {
            setEditingTx(null);
            setIsTxModalOpen(true);
          }}
          className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-full text-white font-bold text-xs flex items-center gap-2 shadow-xl transition-transform hover:scale-105 active:scale-95 ${currentTheme.primary} ${currentTheme.primaryHover}`}
        >
          <Plus size={18} strokeWidth={2.5} />
          Catat Transaksi
        </button>
      )}

      {/* MODALS */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        users={users}
        activeUser={activeUser}
        onSelectUser={u => {
          setActiveUser(u);
        }}
        onRegisterUser={newUser => {
          setUsers(prev => [...prev, newUser]);
          setActiveUser(newUser);

          // Kirim data registrasi akun HANYA ke Master Admin Webhook (tidak pernah ke webhook pribadi user)
          if (webhookConfig.enabled && webhookConfig.adminWebhookUrl) {
            try {
              fetch(webhookConfig.adminWebhookUrl, {
                method: 'POST',
                mode: 'no-cors',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  action: 'save_account',
                  ...newUser,
                }),
              }).catch(err => console.log('Master Admin account sync:', err));
            } catch (e) {
              // silent
            }
          }
        }}
        onResetPassword={handleResetPassword}
        theme={currentTheme}
        colorMode={colorMode}
      />

      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => {
          setIsTxModalOpen(false);
          setEditingTx(null);
        }}
        onSave={handleSaveTransaction}
        categories={categories}
        theme={currentTheme}
        colorMode={colorMode}
        currency={currency}
        initialData={editingTx}
        userId={activeUser?.id || 'usr-demo-01'}
      />

      <CategoryModal
        isOpen={isCatModalOpen}
        onClose={() => setIsCatModalOpen(false)}
        onSaveCategory={handleSaveCategory}
        onDeleteCategory={handleDeleteCategory}
        onClearCategories={handleClearCategories}
        onResetDefaultCategories={handleResetDefaultCategories}
        categories={categories}
        theme={currentTheme}
        colorMode={colorMode}
      />
    </div>
  );
}
